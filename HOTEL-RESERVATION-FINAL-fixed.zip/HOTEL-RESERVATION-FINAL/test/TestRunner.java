import model.*;
import service.*;

import java.io.File;
import java.nio.file.Files;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Zero-setup tests: no JUnit needed.  Run with run-tests.sh (Linux/Mac) or run-tests.bat (Windows),
 * or in IntelliJ: right-click this file > Run 'TestRunner.main()'.
 * Every test uses a throw-away temp data folder, so your real data/ is never touched.
 */
public class TestRunner {
    static int passed, failed;

    public static void main(String[] args) throws Exception {
        run("Pricing: nights, fees and total", TestRunner::pricing);
        run("Pricing: total is rounded to centavos", TestRunner::rounding);
        run("Card: Luhn check", TestRunner::luhn);
        run("Card: validation rules, expiry, decline card", TestRunner::cards);
        run("E-wallet: OTP must match", TestRunner::otp);
        run("Passwords: hash, verify, legacy plain text", TestRunner::hashing);
        run("Validators: email, username, name, phone, password", TestRunner::validators);
        run("Accounts: unique email/username, login, lockout", TestRunner::accounts);
        run("Accounts: reset needs security answer; admin cannot be reset", TestRunner::reset);
        run("Accounts: migration hashes plain text", TestRunner::migration);
        run("Availability: overlap logic and statuses", TestRunner::availability);
        run("Booking: guests > room limit is refused", TestRunner::guestLimit);
        run("Booking: cash rules (max nights, max unpaid)", TestRunner::cashRules);
        run("Booking: last unit cannot be double-booked", TestRunner::doubleBooking);
        run("Booking: blocked user cannot book", TestRunner::blockedBooking);
        run("Booking: overlap detection for same guest", TestRunner::overlapWarning);
        run("Cancel: free vs late fee vs unpaid cash", TestRunner::cancelPolicy);
        run("Lifecycle: check-in/out and sweep", TestRunner::lifecycle);
        run("Admin rooms: cannot cut units below existing bookings", TestRunner::roomUnits);
        run("Files: atomic save leaves no temp file, tolerates bad lines", TestRunner::files);
        run("Forms: every .form parses and its bindings match the Java fields", FormBindingCheck::check);
        System.out.println("\n" + passed + " passed, " + failed + " failed");
        System.exit(failed == 0 ? 0 : 1);
    }

    interface T { void go() throws Exception; }

    static void run(String name, T t) {
        try {
            freshData();
            t.go();
            passed++;
            System.out.println("PASS  " + name);
        } catch (Throwable e) {
            failed++;
            System.out.println("FAIL  " + name + "  ->  " + e);
        }
    }

    static void check(boolean cond, String msg) {
        if (!cond) {
            throw new AssertionError(msg);
        }
    }

    static void eq(Object a, Object b, String msg) {
        if (!java.util.Objects.equals(a, b)) {
            throw new AssertionError(msg + " (expected " + b + " but was " + a + ")");
        }
    }

    // ---------------------------------------------------------------- helpers

    static File tmp;

    static void freshData() throws Exception {
        tmp = Files.createTempDirectory("hoteltest").toFile();
        tmp.deleteOnExit();
        DataPaths.setDir(tmp);
        LoginGuard.resetAll();
        // one room type with 1 unit and one with 2, so tests stay small
        List<Room> rooms = List.of(
                new Room("ONE", "Single Unit Suite", 1000, 2, 1, "s", "d", new String[]{"a"}, "x.jpg"),
                new Room("TWO", "Twin Unit Room", 500, 3, 2, "s", "d", new String[]{"a"}, "x.jpg"));
        RoomFileHandler.saveRooms(new ArrayList<>(rooms));
    }

    static Room room(String id) {
        return RoomFileHandler.findById(id);
    }

    static User guest(String username) {
        String email = username + "@example.com";
        User u = new User("Test " + username, email, username, PasswordHasher.hash("password1"),
                "Q?", PasswordHasher.hash("blue"));
        check(FileHandler.addUser(u), "could not add " + username);
        return u;
    }

    static BookingDraft draft(String roomId, int inDays, int outDays, int guests, String method) {
        BookingDraft d = new BookingDraft();
        d.setRoom(room(roomId));
        d.setDates(LocalDate.now().plusDays(inDays), LocalDate.now().plusDays(outDays));
        d.setGuests(guests);
        d.setPaymentMethod(method);
        return d;
    }

    static PaymentService.Result cardOk() {
        return PaymentService.payCard("Test", "4242 4242 4242 4242", "12/40", "123");
    }

    static BookingService.BookResult bookCard(User u, String roomId, int in, int out, int guests) {
        return BookingService.book(draft(roomId, in, out, guests, BookingDraft.PAY_CARD), u, u.getFullName(), "09171234567", cardOk());
    }

    static BookingService.BookResult bookCash(User u, String roomId, int in, int out, int guests) {
        return BookingService.book(draft(roomId, in, out, guests, BookingDraft.PAY_CASH), u, u.getFullName(), "09171234567", PaymentService.payCash());
    }

    // ---------------------------------------------------------------- tests

    static void pricing() {
        BookingDraft d = draft("ONE", 1, 4, 2, BookingDraft.PAY_CASH); // 3 nights
        d.setAirportTransfer(true);
        d.setDailyCleaning(true);
        eq(d.nights(), 3, "nights");
        // 3*1000 room + 800 airport + 3*300 cleaning + 3*250 service
        eq(d.total(), 3000 + 800 + 900 + 750.0, "total");
    }

    static void rounding() {
        Room odd = new Room("X", "x", 1234.567, 2, 1, "", "", new String[]{}, "");
        BookingDraft d = new BookingDraft();
        d.setRoom(odd);
        d.setDates(LocalDate.now().plusDays(1), LocalDate.now().plusDays(2));
        double t = d.total();
        eq(Math.round(t * 100) / 100.0, t, "total must already have at most 2 decimals");
    }

    static void luhn() {
        check(PaymentService.luhnValid("4242424242424242"), "valid test card");
        check(!PaymentService.luhnValid("4242424242424241"), "bad check digit");
    }

    static void cards() {
        check(cardOk().approved, "good card approved");
        check(!PaymentService.payCard("", "4242424242424242", "12/40", "123").approved, "empty holder");
        check(!PaymentService.payCard("A", "4242424242424241", "12/40", "123").approved, "bad Luhn");
        check(!PaymentService.payCard("A", "4242424242424242", "01/20", "123").approved, "expired");
        check(!PaymentService.payCard("A", "4242424242424242", "13/30", "123").approved, "bad month");
        check(!PaymentService.payCard("A", "4242424242424242", "12/40", "12").approved, "short cvv");
        PaymentService.Result declined = PaymentService.payCard("A", "4000000000000002", "12/40", "123");
        check(!declined.approved, "bank decline card");
        check(!cardOk().reference.contains("4242 4242"), "full number must never be stored");
    }

    static void otp() {
        String code = PaymentService.newOtp();
        eq(code.length(), 6, "otp length");
        check(PaymentService.payEWallet("GCash", "09171234567", code, code).approved, "right code");
        check(!PaymentService.payEWallet("GCash", "09171234567", "000000".equals(code) ? "111111" : "000000", code).approved, "wrong code");
        check(!PaymentService.payEWallet("GCash", "12345", code, code).approved, "bad number");
    }

    static void hashing() {
        String h = PasswordHasher.hash("secret123");
        check(h.startsWith("pbkdf2$") && !h.contains("|") && !h.contains("secret123"), "format");
        check(PasswordHasher.verify("secret123", h), "verify ok");
        check(!PasswordHasher.verify("secret124", h), "verify wrong");
        check(!h.equals(PasswordHasher.hash("secret123")), "salted: same password gives different hash");
        check(PasswordHasher.verify("old", "old"), "legacy plain text still accepted");
    }

    static void validators() {
        check(Validators.email("a@b.com") == null, "email ok");
        check(Validators.email("a@.") != null, "a@. rejected");
        check(Validators.email("a b@c.com") != null, "space rejected");
        check(Validators.username("maria_s") == null, "user ok");
        check(Validators.username("ma ria") != null, "space in username");
        check(Validators.username("ab") != null, "too short");
        check(Validators.fullName("Maria Santos") == null, "name ok");
        check(Validators.fullName("12345") != null, "digits-only name");
        check(Validators.phone("0917 555 0194") == null, "phone ok");
        check(Validators.phone("12345") != null, "phone bad");
        check(Validators.password("abc12345") == null, "pw ok");
        check(Validators.password("abcdefgh") != null, "pw no digit");
        check(Validators.password("a1") != null, "pw short");
    }

    static void accounts() {
        guest("maria");
        check(!FileHandler.addUser(new User("X", "maria@example.com", "other", "h", "", "")), "duplicate email refused");
        check(!FileHandler.addUser(new User("X", "new@example.com", "MARIA", "h", "", "")), "duplicate username (any case) refused");
        check(FileHandler.emailExists("MARIA@example.com"), "email check ignores case");
        check(FileHandler.login("maria", "password1") != null, "login ok");
        check(FileHandler.login("maria", "nope") == null, "login wrong pw");
        for (int i = 0; i < LoginGuard.MAX_FAILS; i++) {
            FileHandler.login("maria", "wrong" + i);
        }
        check(LoginGuard.secondsLocked("maria") > 0, "locked after repeated failures");
        check(FileHandler.login("maria", "password1") == null, "even the right password is refused while locked");
    }

    static void reset() {
        guest("rita");
        check(FileHandler.resetPassword("rita", "rita@example.com", "wrong", "newpass12") != null, "wrong answer");
        check(FileHandler.resetPassword("rita", "other@example.com", "blue", "newpass12") != null, "wrong email");
        eq(FileHandler.securityQuestionFor("rita", "rita@example.com"), "Q?", "question shown");
        eq(FileHandler.resetPassword("rita", "rita@example.com", "  BLUE ", "newpass12"), null, "right answer (case/space-insensitive)");
        check(FileHandler.login("rita", "newpass12") != null, "new password works");
        // admin can never be reset
        FileHandler.addUser(new User("Boss", "boss@example.com", "boss", PasswordHasher.hash("adminpass1"), User.ADMIN, false, "", "Q?", PasswordHasher.hash("blue")));
        check(FileHandler.resetPassword("boss", "boss@example.com", "blue", "hacked1234") != null, "admin reset refused");
        check(FileHandler.login("boss", "adminpass1") != null, "admin password unchanged");
        check(FileHandler.securityQuestionFor("boss", "boss@example.com") == null, "no question shown for admin");
        // account without security question cannot self-reset
        FileHandler.addUser(new User("Old", "old@example.com", "oldie", PasswordHasher.hash("password1"), User.GUEST, false, ""));
        check(FileHandler.resetPassword("oldie", "old@example.com", "x", "newpass12") != null, "no question = no self-reset");
    }

    static void migration() throws Exception {
        Files.writeString(new File(tmp, "users.txt").toPath(),
                "Old Guy|old@example.com|oldguy|plain123|GUEST|ACTIVE|\n");
        eq(FileHandler.migratePasswords(), 1, "one password migrated");
        String line = Files.readString(new File(tmp, "users.txt").toPath());
        check(!line.contains("plain123"), "plain text gone from file");
        check(FileHandler.login("oldguy", "plain123") != null, "can still log in");
    }

    static void availability() {
        User u = guest("avail");
        Room r = room("ONE");
        LocalDate in = LocalDate.now().plusDays(10);
        check(bookCard(u, "ONE", 10, 13, 2).ok, "first booking");
        eq(ReservationFileHandler.roomsLeft(r, in, in.plusDays(3)), 0, "same dates are full");
        eq(ReservationFileHandler.roomsLeft(r, in.minusDays(2), in.plusDays(1)), 0, "partial overlap at start");
        eq(ReservationFileHandler.roomsLeft(r, in.plusDays(2), in.plusDays(5)), 0, "partial overlap at end");
        eq(ReservationFileHandler.roomsLeft(r, in.plusDays(3), in.plusDays(5)), 1, "check-in on the other guest's check-out day is fine");
        eq(ReservationFileHandler.roomsLeft(r, in.minusDays(3), in), 1, "check-out on the other guest's check-in day is fine");
        Reservation res = ReservationFileHandler.loadAll().get(0);
        BookingService.cancel(res, false, false);
        eq(ReservationFileHandler.roomsLeft(r, in, in.plusDays(3)), 1, "cancelled booking frees the room");
        // same answer with a preloaded list
        eq(ReservationFileHandler.roomsLeft(r, in, in.plusDays(3), ReservationFileHandler.loadAll()), 1, "preloaded list overload");
    }

    static void guestLimit() {
        User u = guest("fam");
        BookingService.BookResult res = bookCard(u, "ONE", 5, 7, 3); // ONE fits 2
        check(!res.ok && res.message.contains("at most 2"), "3 guests in a 2-guest room refused: " + res.message);
        check(ReservationFileHandler.loadAll().isEmpty(), "nothing saved");
    }

    static void cashRules() {
        User u = guest("cashy");
        BookingService.BookResult longCash = bookCash(u, "TWO", 5, 13, 1); // 8 nights
        check(!longCash.ok && longCash.message.contains("7 nights"), "8-night cash refused: " + longCash.message);
        check(bookCash(u, "TWO", 20, 22, 1).ok, "1st cash booking");
        check(bookCash(u, "TWO", 30, 32, 1).ok, "2nd cash booking");
        BookingService.BookResult third = bookCash(u, "TWO", 40, 42, 1);
        check(!third.ok && third.message.contains("unpaid cash"), "3rd unpaid cash refused: " + third.message);
        check(bookCard(u, "TWO", 40, 42, 1).ok, "card booking still allowed");
    }

    static void doubleBooking() {
        User a = guest("aa");
        User b = guest("bb");
        check(bookCard(a, "ONE", 10, 12, 1).ok, "first wins");
        BookingService.BookResult second = bookCard(b, "ONE", 11, 13, 1);
        check(!second.ok, "second refused (service re-checks availability at save time)");
        eq(ReservationFileHandler.loadAll().size(), 1, "only one reservation saved");
        eq(PaymentFileHandler.loadAll().size(), 1, "only one payment saved");
    }

    static void blockedBooking() {
        User u = guest("troll");
        FileHandler.setBlocked("troll", true, "spam");
        check(!bookCash(u, "TWO", 5, 6, 1).ok, "blocked user refused even though the object in memory is stale");
        check(!FileHandler.setBlocked("nobody", true, "x"), "unknown user");
    }

    static void overlapWarning() {
        User u = guest("twice");
        bookCard(u, "TWO", 10, 14, 1);
        eq(BookingService.overlapping("twice", LocalDate.now().plusDays(12), LocalDate.now().plusDays(16)).size(), 1, "overlap found");
        eq(BookingService.overlapping("twice", LocalDate.now().plusDays(14), LocalDate.now().plusDays(16)).size(), 0, "back-to-back is not overlap");
    }

    static void cancelPolicy() {
        User u = guest("canc");
        // far away (10 days) -> free, full refund
        Reservation far = bookCard(u, "TWO", 10, 12, 1).reservation; // total = 2*500+2*250 = 1500
        BookingService.CancelResult c1 = BookingService.cancel(far, false, false);
        check(c1.ok, "far cancel ok");
        Payment p1 = PaymentFileHandler.findByBooking(far.getBookingId());
        eq(p1.getStatus(), Payment.REFUNDED, "refunded");
        eq(p1.getRefundAmount(), p1.getAmount(), "full refund");
        eq(p1.getRetained(), 0.0, "nothing kept");

        // tomorrow -> late fee = one night's average (total/nights)
        Reservation late = bookCard(u, "TWO", 1, 3, 1).reservation;
        BookingService.cancel(late, false, false);
        Payment p2 = PaymentFileHandler.findByBooking(late.getBookingId());
        eq(p2.getRefundAmount(), p2.getAmount() / 2, "late: half of a 2-night stay refunded");
        eq(p2.getRetained(), p2.getAmount() / 2, "late: one night kept");

        // admin can waive
        Reservation waived = bookCard(u, "TWO", 1, 3, 1).reservation;
        BookingService.cancel(waived, true, true);
        eq(PaymentFileHandler.findByBooking(waived.getBookingId()).getRetained(), 0.0, "waived fee");

        // unpaid cash: VOID, no fee
        Reservation cash = bookCash(u, "TWO", 1, 2, 1).reservation;
        BookingService.cancel(cash, false, false);
        eq(PaymentFileHandler.findByBooking(cash.getBookingId()).getStatus(), Payment.VOID, "unpaid cash voided");

        // cannot cancel twice or after check-in day (guest)
        check(!BookingService.cancel(far, false, false).ok, "cannot cancel twice");
        Reservation started = new Reservation("TT-X", "canc", "n", "c", "TWO", "Twin", LocalDate.now().minusDays(1), LocalDate.now().plusDays(2), 1, "", "Cash", 100, Reservation.CONFIRMED);
        check(!CancellationPolicy.canCancel(started, LocalDate.now(), false), "guest cannot cancel after check-in day");
        check(CancellationPolicy.canCancel(started, LocalDate.now(), true), "admin can (e.g. before no-show sweep)");
    }

    static void lifecycle() {
        User u = guest("stay");
        Reservation future = bookCash(u, "TWO", 5, 7, 1).reservation;
        check(!BookingService.checkIn(future, true).ok, "too early to check in");

        // a booking that starts today
        Reservation today = bookCash(u, "TWO", 0, 2, 1).reservation;
        check(!BookingService.checkIn(today, false).ok, "pending cash must be collected first");
        check(BookingService.checkIn(today, true).ok, "check-in after collecting cash");
        eq(PaymentFileHandler.findByBooking(today.getBookingId()).getStatus(), Payment.PAID, "cash now PAID");
        Reservation inHouse = ReservationFileHandler.loadAll().stream().filter(r -> r.getBookingId().equals(today.getBookingId())).findFirst().get();
        eq(inHouse.getStatus(), Reservation.CHECKED_IN, "status");
        check(BookingService.checkOut(inHouse).ok, "check-out");

        // sweep: old confirmed -> NO_SHOW, old checked-in -> COMPLETED
        ArrayList<Reservation> all = new ArrayList<>();
        all.add(new Reservation("TT-2020-0001", "stay", "n", "c", "TWO", "T", LocalDate.now().minusDays(10), LocalDate.now().minusDays(8), 1, "", "Cash", 100, Reservation.CONFIRMED));
        all.add(new Reservation("TT-2020-0002", "stay", "n", "c", "TWO", "T", LocalDate.now().minusDays(10), LocalDate.now().minusDays(8), 1, "", "Cash", 100, Reservation.CHECKED_IN));
        ReservationFileHandler.saveAll(all);
        PaymentFileHandler.add(new Payment("PAY-2020-0001", "TT-2020-0001", "stay", "Cash", "Pay at front desk", 100, Payment.PENDING, LocalDateTime.now()));
        eq(BookingService.sweep(LocalDate.now()), 2, "two changed");
        List<Reservation> after = ReservationFileHandler.loadAll();
        eq(after.get(0).getStatus(), Reservation.NO_SHOW, "no-show");
        eq(after.get(1).getStatus(), Reservation.COMPLETED, "completed");
        eq(PaymentFileHandler.findByBooking("TT-2020-0001").getStatus(), Payment.VOID, "uncollected cash voided");
        eq(BookingService.sweep(LocalDate.now()), 0, "sweep is idempotent");
    }

    static void roomUnits() {
        User a = guest("ra");
        User b = guest("rb");
        check(bookCard(a, "TWO", 10, 14, 1).ok, "booking 1");
        check(bookCard(b, "TWO", 12, 16, 1).ok, "booking 2 overlaps booking 1");
        eq(BookingService.maxBookedAtOnce("TWO", LocalDate.now()), 2, "both overlap on nights 12-13");
        check(bookCard(a, "TWO", 20, 22, 1).ok, "booking 3 does not overlap");
        eq(BookingService.maxBookedAtOnce("TWO", LocalDate.now()), 2, "still 2 at most");
        eq(BookingService.maxBookedAtOnce("ONE", LocalDate.now()), 0, "other room type unaffected");
    }

    static void files() throws Exception {
        guest("filey");
        File[] leftovers = tmp.listFiles((d, n) -> n.endsWith(".tmp"));
        eq(leftovers.length, 0, "no .tmp files left behind");
        Files.writeString(new File(tmp, "reservations.txt").toPath(), "garbage line\n\nTT-1|a|b\n");
        eq(ReservationFileHandler.loadAll().size(), 0, "bad lines are skipped, not crashed on");
        Files.writeString(new File(tmp, "payments.txt").toPath(),
                "PAY-2026-0001|TT-2026-0001|u|Cash|ref|100.00|REFUNDED|2026-01-01T10:00\n");
        eq(PaymentFileHandler.loadAll().get(0).getRefundAmount(), 100.0, "legacy 8-field REFUNDED = full refund");
    }
}
