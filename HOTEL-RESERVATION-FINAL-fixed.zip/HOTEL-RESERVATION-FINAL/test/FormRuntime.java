import com.intellij.uiDesigner.core.GridConstraints;
import com.intellij.uiDesigner.core.GridLayoutManager;
import com.intellij.uiDesigner.core.Spacer;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.Border;
import javax.xml.parsers.DocumentBuilderFactory;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * A test-only stand-in for what IntelliJ does when it compiles a .form: it builds the component tree
 * described by the form and assigns every binding="..." field of the owner object.
 * That lets the tests (and screenshots) exercise the real form + the real screen class without IntelliJ.
 *
 * Screens follow the usual pattern:  constructor { ...; init(); }  where init() uses the bound fields.
 * IntelliJ fills the fields right at the start of the constructor; here we do it with
 * newScreen(): allocate the object, fill the fields from the .form, then run the constructor body.
 */
public class FormRuntime {

    /**
     * Creates a screen exactly like IntelliJ's compiled form would: the bound fields are filled from the
     * .form first, then the constructor body (our init()) runs.  presets = pairs of (fieldName, value)
     * for the constructor arguments, e.g. newScreen(PaymentsPanel.class, "user", someUser).
     */
    @SuppressWarnings("unchecked")
    public static <T> T newScreen(Class<T> cls, Object... presets) throws Exception {
        Field uf = Class.forName("sun.misc.Unsafe").getDeclaredField("theUnsafe");
        uf.setAccessible(true);
        Object unsafe = uf.get(null);
        T obj = (T) unsafe.getClass().getMethod("allocateInstance", Class.class).invoke(unsafe, cls);
        for (int k = 0; k + 1 < presets.length; k += 2) {
            Field f = cls.getDeclaredField((String) presets[k]);
            f.setAccessible(true);
            f.set(obj, presets[k + 1]);
        }
        build(obj, new File("src/ui/" + cls.getSimpleName() + ".form"));
        Method init = cls.getDeclaredMethod("init");
        init.setAccessible(true);
        init.invoke(obj);
        return obj;
    }

    public static JComponent build(Object owner, File formFile) throws Exception {
        Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(formFile);
        Element root = doc.getDocumentElement();
        Method custom = null;
        for (Method m : owner.getClass().getDeclaredMethods()) {
            if (m.getName().equals("createUIComponents")) {
                custom = m;
            }
        }
        if (custom != null) {
            custom.setAccessible(true);
            custom.invoke(owner);
        }
        Element top = null;
        for (Node n = root.getFirstChild(); n != null; n = n.getNextSibling()) {
            if (n instanceof Element) {
                top = (Element) n;
                break;
            }
        }
        return (JComponent) make(top, owner, null);
    }

    // ------------------------------------------------------------------ building

    static Component make(Element e, Object owner, Container parent) throws Exception {
        Component c;
        String tag = e.getTagName();
        String binding = e.getAttribute("binding");
        boolean custom = "true".equals(e.getAttribute("custom-create"));
        switch (tag) {
            case "grid": {
                JPanel p = new JPanel();
                p.setLayout(layoutFor(e));
                applyBorder(e, p);
                c = p;
                break;
            }
            case "scrollpane":
                c = new JScrollPane();
                break;
            case "vspacer":
            case "hspacer":
                c = new Spacer();
                break;
            case "component":
                if (custom) {
                    Field f = owner.getClass().getDeclaredField(binding);
                    f.setAccessible(true);
                    c = (Component) f.get(owner);
                    if (c == null) {
                        throw new IllegalStateException("custom-create field " + binding + " not set by createUIComponents()");
                    }
                } else {
                    c = (Component) Class.forName(e.getAttribute("class")).getDeclaredConstructor().newInstance();
                }
                break;
            default:
                throw new IllegalStateException("unsupported tag " + tag);
        }
        if (!binding.isEmpty()) {
            Field f = owner.getClass().getDeclaredField(binding);
            f.setAccessible(true);
            f.set(owner, c);
        }
        applyProperties(e, c);
        Element kids = firstChildElement(e, "children");
        if (kids != null) {
            for (Node n = kids.getFirstChild(); n != null; n = n.getNextSibling()) {
                if (n instanceof Element) {
                    Element ce = (Element) n;
                    Component child = make(ce, owner, (Container) c);
                    if (c instanceof JScrollPane) {
                        ((JScrollPane) c).setViewportView(child);
                    } else {
                        ((Container) c).add(child, constraintsFor(ce, ((Container) c).getLayout()));
                    }
                }
            }
        }
        return c;
    }

    static java.awt.LayoutManager layoutFor(Element e) {
        String lm = e.getAttribute("layout-manager");
        int hgap = Integer.parseInt(e.getAttribute("hgap"));
        int vgap = Integer.parseInt(e.getAttribute("vgap"));
        switch (lm) {
            case "BorderLayout":
                return new BorderLayout(Math.max(0, hgap), Math.max(0, vgap));
            case "CardLayout":
                return new CardLayout(Math.max(0, hgap), Math.max(0, vgap));
            case "GridLayoutManager": {
                Element m = firstChildElement(e, "margin");
                Insets in = new Insets(i(m, "top"), i(m, "left"), i(m, "bottom"), i(m, "right"));
                return new GridLayoutManager(Integer.parseInt(e.getAttribute("row-count")),
                        Integer.parseInt(e.getAttribute("column-count")), in, hgap, vgap,
                        "true".equals(e.getAttribute("same-size-horizontally")),
                        "true".equals(e.getAttribute("same-size-vertically")));
            }
            default:
                throw new IllegalStateException("unsupported layout " + lm);
        }
    }

    static Object constraintsFor(Element child, java.awt.LayoutManager lm) {
        Element cons = firstChildElement(child, "constraints");
        if (lm instanceof BorderLayout) {
            return cons.getAttribute("border-constraint");
        }
        if (lm instanceof CardLayout) {
            return firstChildElement(cons, "card").getAttribute("name");
        }
        Element g = firstChildElement(cons, "grid");
        Dimension pref = null;
        Dimension min = null;
        Element ms = firstChildElement(g, "minimum-size");
        if (ms != null) {
            min = new Dimension(i(ms, "width"), i(ms, "height"));
        }
        Element ps = firstChildElement(g, "preferred-size");
        if (ps != null) {
            pref = new Dimension(i(ps, "width"), i(ps, "height"));
        }
        return new GridConstraints(i(g, "row"), i(g, "column"), i(g, "row-span"), i(g, "col-span"),
                i(g, "anchor"), i(g, "fill"), i(g, "hsize-policy"), i(g, "vsize-policy"),
                min, pref, null, i(g, "indent"), "true".equals(g.getAttribute("use-parent-layout")));
    }

    static void applyBorder(Element e, JPanel p) {
        Element b = firstChildElement(e, "border");
        if (b == null) {
            return;
        }
        Border border = null;
        switch (b.getAttribute("type")) {
            case "line":
                border = BorderFactory.createLineBorder(new Color(i(firstChildElement(b, "color"), "color")));
                break;
            case "empty": {
                Element s = firstChildElement(b, "size");
                border = BorderFactory.createEmptyBorder(i(s, "top"), i(s, "left"), i(s, "bottom"), i(s, "right"));
                break;
            }
            default:
        }
        if (border != null) {
            p.setBorder(border);
        }
    }

    static void applyProperties(Element e, Component c) throws Exception {
        Element props = firstChildElement(e, "properties");
        if (props == null) {
            return;
        }
        for (Node n = props.getFirstChild(); n != null; n = n.getNextSibling()) {
            if (!(n instanceof Element)) {
                continue;
            }
            Element p = (Element) n;
            switch (p.getTagName()) {
                case "text":
                    call(c, "setText", String.class, p.getAttribute("value"));
                    break;
                case "font":
                    c.setFont(new Font(p.getAttribute("name"), i(p, "style"), i(p, "size")));
                    break;
                case "foreground":
                    c.setForeground(new Color(i(p, "color")));
                    break;
                case "background":
                    c.setBackground(new Color(i(p, "color")));
                    break;
                case "opaque":
                    ((JComponent) c).setOpaque(Boolean.parseBoolean(p.getAttribute("value")));
                    break;
                case "horizontalAlignment":
                    call(c, "setHorizontalAlignment", int.class, i(p, "value"));
                    break;
                case "preferred-size":
                    c.setPreferredSize(new Dimension(i(p, "width"), i(p, "height")));
                    break;
                case "editable":
                    call(c, "setEditable", boolean.class, Boolean.parseBoolean(p.getAttribute("value")));
                    break;
                case "toolTipText":
                    ((JComponent) c).setToolTipText(p.getAttribute("value"));
                    break;
                case "selected":
                    call(c, "setSelected", boolean.class, Boolean.parseBoolean(p.getAttribute("value")));
                    break;
                default:
                    throw new IllegalStateException("unsupported property " + p.getTagName());
            }
        }
    }

    static void call(Component c, String name, Class<?> type, Object value) throws Exception {
        c.getClass().getMethod(name, type).invoke(c, value);
    }

    static int i(Element e, String attr) {
        return Integer.parseInt(e.getAttribute(attr));
    }

    static Element firstChildElement(Element parent, String name) {
        if (parent == null) {
            return null;
        }
        for (Node n = parent.getFirstChild(); n != null; n = n.getNextSibling()) {
            if (n instanceof Element && (name == null || ((Element) n).getTagName().equals(name))) {
                return (Element) n;
            }
        }
        return null;
    }

    /** every component under c, depth first */
    public static List<Component> all(Container c) {
        List<Component> out = new ArrayList<>();
        for (Component k : c.getComponents()) {
            out.add(k);
            if (k instanceof Container) {
                out.addAll(all((Container) k));
            }
        }
        return out;
    }
}
