import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.HashSet;
import java.util.Set;

/**
 * Static check of the IntelliJ GUI Designer forms (no IntelliJ needed).
 * For every src/ui/*.form it verifies:
 *   - the XML parses and every component id is unique
 *   - bind-to-class names a real class
 *   - every binding="x" is a NON-final field called x in that class, whose type fits the component
 *   - no field is bound twice; custom-create components have a createUIComponents() method
 *   - grid cells are inside the grid's row/column count
 * The screens listed in MUST_BE_BOUND have to be really driven by their form (at least 1 binding + a root panel).
 */
public class FormBindingCheck {
    static final Set<String> MUST_BE_BOUND = new HashSet<>(java.util.Arrays.asList(
            "ui.LoginPanel", "ui.PaymentsPanel", "ui.ProfilePanel", "ui.AdminDashboardPanel", "ui.AdminRoomsPanel"));

    public static void check() throws Exception {
        File dir = new File("src/ui");
        File[] forms = dir.listFiles((d, n) -> n.endsWith(".form"));
        if (forms == null || forms.length == 0) {
            throw new AssertionError("no .form files found in src/ui (run from the project root)");
        }
        StringBuilder problems = new StringBuilder();
        int bound = 0;
        for (File f : forms) {
            Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(f);
            Element root = doc.getDocumentElement();
            String cls = root.getAttribute("bind-to-class");
            Class<?> c;
            try {
                c = Class.forName(cls, false, FormBindingCheck.class.getClassLoader());
            } catch (ClassNotFoundException e) {
                problems.append(f.getName()).append(": class ").append(cls).append(" not found\n");
                continue;
            }
            Set<String> ids = new HashSet<>();
            Set<String> bindings = new HashSet<>();
            walk(root, c, f.getName(), ids, bindings, problems);
            if (!bindings.isEmpty()) {
                bound++;
            }
            if (MUST_BE_BOUND.contains(cls) && !bindings.contains("rootPanel")) {
                problems.append(f.getName()).append(": must bind its root panel to a field named rootPanel\n");
            }
        }
        if (problems.length() > 0) {
            throw new AssertionError("\n" + problems);
        }
        System.out.println("      (" + forms.length + " forms checked, " + bound + " drive their screen through bindings)");
    }

    static void walk(Element e, Class<?> c, String file, Set<String> ids, Set<String> bindings, StringBuilder problems) throws Exception {
        String tag = e.getTagName();
        // note: <grid row=.. column=..> inside <constraints> is a cell position, not a component (it has no layout-manager)
        boolean isComponent = tag.equals("component") || (tag.equals("grid") && e.hasAttribute("layout-manager")) || tag.equals("scrollpane")
                || tag.equals("tabbedpane") || tag.equals("splitpane") || tag.equals("hspacer") || tag.equals("vspacer");
        if (isComponent) {
            String id = e.getAttribute("id");
            if (!ids.add(id)) {
                problems.append(file).append(": duplicate id ").append(id).append('\n');
            }
            String binding = e.getAttribute("binding");
            if (!binding.isEmpty()) {
                if (!bindings.add(binding)) {
                    problems.append(file).append(": field ").append(binding).append(" bound twice\n");
                }
                Field fld = null;
                try {
                    fld = c.getDeclaredField(binding);
                } catch (NoSuchFieldException ex) {
                    problems.append(file).append(": no field '").append(binding).append("' in ").append(c.getSimpleName()).append('\n');
                }
                if (fld != null) {
                    if (Modifier.isFinal(fld.getModifiers())) {
                        problems.append(file).append(": field '").append(binding).append("' is final (the designer must assign it)\n");
                    }
                    Class<?> expected = expectedType(e);
                    if (expected != null && !fld.getType().isAssignableFrom(expected)) {
                        problems.append(file).append(": field '").append(binding).append("' is ").append(fld.getType().getSimpleName())
                                .append(" but the form has a ").append(expected.getSimpleName()).append('\n');
                    }
                }
            }
            if ("true".equals(e.getAttribute("custom-create"))) {
                boolean has = false;
                for (java.lang.reflect.Method m : c.getDeclaredMethods()) {
                    has |= m.getName().equals("createUIComponents");
                }
                if (!has) {
                    problems.append(file).append(": custom-create used but ").append(c.getSimpleName()).append(" has no createUIComponents()\n");
                }
            }
            if (tag.equals("grid") && e.getAttribute("layout-manager").equals("GridLayoutManager")) {
                int rows = Integer.parseInt(e.getAttribute("row-count"));
                int cols = Integer.parseInt(e.getAttribute("column-count"));
                NodeList kids = children(e);
                for (int i = 0; i < kids.getLength(); i++) {
                    Element g = firstGrid(kids.item(i));
                    if (g != null) {
                        int r = Integer.parseInt(g.getAttribute("row")) + Integer.parseInt(g.getAttribute("row-span"));
                        int co = Integer.parseInt(g.getAttribute("column")) + Integer.parseInt(g.getAttribute("col-span"));
                        if (r > rows || co > cols) {
                            problems.append(file).append(": a child of grid ").append(id).append(" is outside the ")
                                    .append(rows).append("x").append(cols).append(" grid\n");
                        }
                    }
                }
            }
        }
        NodeList all = e.getChildNodes();
        for (int i = 0; i < all.getLength(); i++) {
            if (all.item(i) instanceof Element) {
                walk((Element) all.item(i), c, file, ids, bindings, problems);
            }
        }
    }

    static NodeList children(Element grid) {
        NodeList l = grid.getChildNodes();
        for (int i = 0; i < l.getLength(); i++) {
            if (l.item(i) instanceof Element && ((Element) l.item(i)).getTagName().equals("children")) {
                return l.item(i).getChildNodes();
            }
        }
        return grid.getOwnerDocument().createElement("x").getChildNodes();
    }

    static Element firstGrid(Node child) {
        if (!(child instanceof Element)) {
            return null;
        }
        NodeList l = child.getChildNodes();
        for (int i = 0; i < l.getLength(); i++) {
            if (l.item(i) instanceof Element && ((Element) l.item(i)).getTagName().equals("constraints")) {
                NodeList cs = l.item(i).getChildNodes();
                for (int j = 0; j < cs.getLength(); j++) {
                    if (cs.item(j) instanceof Element && ((Element) cs.item(j)).getTagName().equals("grid")) {
                        return (Element) cs.item(j);
                    }
                }
            }
        }
        return null;
    }

    static Class<?> expectedType(Element e) throws Exception {
        switch (e.getTagName()) {
            case "grid": return javax.swing.JPanel.class;
            case "scrollpane": return javax.swing.JScrollPane.class;
            case "tabbedpane": return javax.swing.JTabbedPane.class;
            case "component": return Class.forName(e.getAttribute("class"));
            default: return null;
        }
    }
}
