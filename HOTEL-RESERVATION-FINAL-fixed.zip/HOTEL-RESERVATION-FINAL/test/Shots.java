import model.User;
import ui.*;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

/** Renders the form-driven screens to PNG files (headless) so layouts can be checked without IntelliJ. */
public class Shots {
    static void layoutAll(Container c) {
        c.doLayout();
        for (Component k : c.getComponents()) {
            if (k instanceof Container) {
                layoutAll((Container) k);
            }
        }
    }

    static void shot(JComponent root, int w, int h, String file) throws Exception {
        root.setSize(w, h);
        layoutAll(root);
        layoutAll(root);
        BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = img.createGraphics();
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, w, h);
        root.paint(g);
        g.dispose();
        new File(file).getParentFile().mkdirs();
        ImageIO.write(img, "png", new File(file));
    }

    public static void main(String[] a) throws Exception {
        String out = a.length > 0 ? a[0] : "/tmp/shots";
        LoginPanel login = FormRuntime.newScreen(LoginPanel.class, "frame", null);
        shot(login.getRootPanel(), 1000, 600, out + "/login.png");
        java.lang.reflect.Field f = LoginPanel.class.getDeclaredField("cardContainer");
        f.setAccessible(true);
        JPanel cards = (JPanel) f.get(login);
        for (String n : new String[]{"CREATE", "RESET"}) {
            ((CardLayout) cards.getLayout()).show(cards, n);
            shot(login.getRootPanel(), 1000, 600, out + "/login_" + n.toLowerCase() + ".png");
        }
        User u = new User("Maria Santos", "maria@example.com", "maria", "x", "", "");
        PaymentsPanel pay = FormRuntime.newScreen(PaymentsPanel.class, "user", u);
        shot(pay.getRootPanel(), 784, 600, out + "/payments.png");
        ProfilePanel prof = FormRuntime.newScreen(ProfilePanel.class, "user", u);
        shot(prof.getRootPanel(), 784, 600, out + "/profile.png");
        AdminDashboardPanel dash = FormRuntime.newScreen(AdminDashboardPanel.class);
        shot(dash.getRootPanel(), 784, 600, out + "/dashboard.png");
        AdminRoomsPanel rooms = FormRuntime.newScreen(AdminRoomsPanel.class);
        shot(rooms.getRootPanel(), 784, 600, out + "/rooms.png");
        System.out.println("shots written to " + out);
    }
}
