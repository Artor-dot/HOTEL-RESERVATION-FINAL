import model.*;
import service.*;

import java.io.File;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;

/**
 * Resets data/ to a clean demo set. Dates are relative to TODAY, so the demo never goes stale.
 * Run:  ./seed-demo-data.sh   (or seed-demo-data.bat)   - run it the day before presenting.
 * It rewrites users.txt, reservations.txt and payments.txt (rooms.txt is left alone).
 *
 * Demo logins (also in README):
 *   admin / Admin2026!   demo / Demo1234   maria / Maria1234   jose / Jose1234
 *   spamuser (blocked)   - shows the blocklist; cannot log in
 */
public class SeedData {
    static final String Q = "What was the name of your first pet?";

    public static void main(String[] args) {
        if (!DataPaths.looksValid()) {
            System.out.println("Run this from the project folder (the one containing data/).");
            return;
        }
        LocalDate today = LocalDate.now();

        ArrayList<User> users = new ArrayList<>();
        users.add(new User("Hotel Administrator", "admin@triplethreat.com", "admin", PasswordHasher.hash("Admin2026!"), User.ADMIN, false, "", "", ""));
        users.add(guest("Demo Guest", "demo@example.com", "demo", "Demo1234", "biscuit"));
        users.add(guest("Maria Santos", "maria.santos@example.com", "maria", "Maria1234", "luna"));
        users.add(guest("Jose Reyes", "jose.reyes@example.com", "jose", "Jose1234", "max"));
        users.add(new User("Spam User", "spam@example.com", "spamuser", PasswordHasher.hash("Spam1234"), User.GUEST, true,
                "Repeated fake bookings", Q, PasswordHasher.hash("x1")));
        FileHandler.saveUsers(users);

        ArrayList<Reservation> res = new ArrayList<>();
        ArrayList<Payment> pays = new ArrayList<>();
        int[] seq = {0, 0};

        // maria: upcoming, paid by card (with airport transfer)
        add(res, pays, seq, "maria", "Maria Santos", "0917 555 0194", "LSD", today.plusDays(14), today.plusDays(17), 2,
                BookingDraft.PAY_CARD, true, "Visa ending 4242", Reservation.CONFIRMED, Payment.PAID, 0);
        // maria: finished stay
        add(res, pays, seq, "maria", "Maria Santos", "0917 555 0194", "STD", today.minusDays(20), today.minusDays(17), 2,
                BookingDraft.PAY_EWALLET, false, "GCash ending 0194", Reservation.COMPLETED, Payment.PAID, 0);
        // jose: upcoming, cash (pending)
        add(res, pays, seq, "jose", "Jose Reyes", "0918 555 0123", "FAM", today.plusDays(30), today.plusDays(33), 4,
                BookingDraft.PAY_CASH, false, "Pay at front desk", Reservation.CONFIRMED, Payment.PENDING, 0);
        // jose: late cancellation, one night's charge kept (policy demo)
        Reservation late = add(res, pays, seq, "jose", "Jose Reyes", "0918 555 0123", "EXE", today.plusDays(1), today.plusDays(3), 2,
                BookingDraft.PAY_CARD, false, "Visa ending 4242", Reservation.CANCELLED, Payment.REFUNDED, 0);
        Payment lp = pays.get(pays.size() - 1);
        lp.setRefundAmount(lp.getAmount() - CancellationPolicy.fee(late, lp.getAmount(), today, false));
        // demo: currently staying
        add(res, pays, seq, "demo", "Demo Guest", "0919 555 0456", "STD", today.minusDays(1), today.plusDays(2), 2,
                BookingDraft.PAY_CARD, false, "Mastercard ending 4444", Reservation.CHECKED_IN, Payment.PAID, 0);
        // spamuser: cancelled, nothing collected
        add(res, pays, seq, "spamuser", "Spam User", "0900 000 0000", "PEN", today.plusDays(10), today.plusDays(12), 2,
                BookingDraft.PAY_CASH, false, "Pay at front desk", Reservation.CANCELLED, Payment.VOID, 0);

        ReservationFileHandler.saveAll(res);
        PaymentFileHandler.saveAll(pays);
        System.out.println("Demo data written: " + users.size() + " users, " + res.size() + " reservations, " + pays.size() + " payments.");
    }

    static User guest(String name, String email, String username, String password, String answer) {
        return new User(name, email, username, PasswordHasher.hash(password), Q,
                PasswordHasher.hash(FileHandler.normalizeAnswer(answer)));
    }

    static Reservation add(ArrayList<Reservation> res, ArrayList<Payment> pays, int[] seq, String username, String guestName,
                           String contact, String roomId, LocalDate in, LocalDate out, int guests, String method,
                           boolean airport, String reference, String resStatus, String payStatus, double refund) {
        Room room = RoomFileHandler.findById(roomId);
        BookingDraft d = new BookingDraft();
        d.setRoom(room);
        d.setDates(in, out);
        d.setGuests(guests);
        d.setPaymentMethod(method);
        d.setAirportTransfer(airport);
        int year = LocalDate.now().getYear();
        String bookingId = String.format("TT-%d-%04d", year, ++seq[0]);
        Reservation r = new Reservation(bookingId, username, guestName, contact, room.getId(), room.getName(),
                in, out, guests, String.join("; ", d.addOnLines()), method, d.total(), resStatus);
        res.add(r);
        pays.add(new Payment(String.format("PAY-%d-%04d", year, ++seq[1]), bookingId, username, method, reference,
                d.total(), payStatus, LocalDateTime.now().minusDays(1), refund));
        return r;
    }
}
