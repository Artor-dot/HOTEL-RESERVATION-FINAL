@echo off
rem Resets data\ to a clean demo set (dates relative to today). Run from the project root.
set OUT=%TEMP%\hotel-seed-out
if exist "%OUT%" rmdir /s /q "%OUT%"
mkdir "%OUT%"
dir /s /b src\*.java tools\*.java > "%OUT%\sources.txt"
javac -encoding UTF-8 -cp lib\forms_rt.jar -d "%OUT%" @"%OUT%\sources.txt" || exit /b 1
java -Djava.awt.headless=true -cp "%OUT%;lib\forms_rt.jar" SeedData
