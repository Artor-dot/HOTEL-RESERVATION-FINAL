#!/bin/sh
# Resets data/ to a clean demo set (dates relative to today). Run from the project root.
set -e
OUT=$(mktemp -d)
javac -encoding UTF-8 -cp lib/forms_rt.jar -d "$OUT" $(find src -name '*.java') tools/SeedData.java
java -Djava.awt.headless=true -cp "$OUT:lib/forms_rt.jar" SeedData
