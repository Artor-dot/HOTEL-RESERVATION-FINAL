# Triple Threat — Hotel Reservation System

A Java Swing desktop app for browsing hotel rooms, booking and paying for a stay, and managing guests, reservations, payments and rooms.
Plain Java, no external libraries (the small `lib/forms_rt.jar` is IntelliJ's GUI-Designer runtime).

## Team
- ANSALI, RAZHIEL
- CABRILLES, ARTHUR JOSHUA
- COMANDAO, YHASHUA
- ENRIQUEZ, GABRIEL MARTINI
- GAMAO, JOHN SEBASTIAN

## How to run (IntelliJ IDEA)
1. **File > Open** the inner folder `HOTEL-RESERVATION-FINAL` (the one containing `src/`, `data/`, `lib/`).
2. Set a JDK (17 or newer) under **File > Project Structure > Project SDK**.
3. **Build > Rebuild Project** once. This is what turns the `.form` files into screens (see "GUI Designer forms").
4. Run `src/Main.java`.

The program finds `data/` even if IntelliJ's working directory is the outer folder. If it cannot, it shows a message instead of starting with empty data.
Only one copy can run at a time (two copies would overwrite each other's files).

## Before you present
Run `seed-demo-data.bat` (Windows) or `./seed-demo-data.sh`. It resets `data/` to a clean demo set with dates relative to **today**, so the sample bookings are never in the past.

| Role | Username | Password | Notes |
|---|---|---|---|
| Admin | `admin` | `Admin2026!` | cannot reset its password from the login screen |
| Guest | `demo` | `Demo1234` | currently checked in |
| Guest | `maria` | `Maria1234` | upcoming paid booking + a finished stay |
| Guest | `jose` | `Jose1234` | cash booking pending + a late cancellation (shows the fee) |
| Guest | `spamuser` | `Spam1234` | **blocked** (shows the blocklist) |

Security answers for the reset demo: `demo` = biscuit, `maria` = luna, `jose` = max.

## Guest features
- **Login / Create Account / Forgot Password** — passwords are stored as salted PBKDF2 hashes. Sign-up needs a unique email, a valid username and a security question. Forgot Password needs username + email + the security answer. 5 wrong tries lock an account for 60 seconds.
- **Browse Rooms** — pick dates and guests (the guest list only offers what the chosen room holds). Each room shows Available / Only N left / Sold Out.
- **Room Details + Stay Calculator**, **Checkout** with a live receipt, and **My Reservations** (cancel with a refund preview).
- **Payments** — your history: paid, due at the desk, refunded.
- **Profile** — edit name/email, change password, set the security question.

## Booking rules (all enforced in `BookingService`, not only on screen)
- Stay: 1 to 30 nights, check-in not in the past, guests must fit the room.
- Cash at the front desk: max 7 nights and max 2 unpaid cash bookings per guest. Longer stays need card or e-wallet.
- Booking the same dates twice asks "book another room?".
- Blocked guests cannot book, and are signed out at their next click.
- **Cancellation policy** (`CancellationPolicy`): free up to 3 days before check-in. Later, one night's average charge is kept and the rest refunded. Unpaid cash has no fee. Admin can waive the fee.
- **Stay lifecycle**: CONFIRMED > CHECKED_IN > COMPLETED, or CANCELLED / NO_SHOW. At check-in the front desk collects any pending cash. Stays that ended without arrival become NO_SHOW automatically.
- A booking and its payment record are saved together; if either save fails, nothing is kept.

## Payments (simulation, no real money moves)
| Method | Guest enters | Result |
|---|---|---|
| Cash at Front Desk | nothing | `PENDING` until collected at check-in |
| Card | number, name, expiry, CVV | Luhn/expiry/CVV checked, then `PAID` |
| E-Wallet | wallet + mobile number | a 6-digit code is "texted" and must be typed, then `PAID` |

Demo mode (`PaymentService.DEMO_MODE`) shows the test card `4242 4242 4242 4242` (`4000 0000 0000 0002` is declined) and displays the wallet code on screen. Only a masked reference (e.g. `Visa ending 4242`) is stored.

## Admin features
- **Dashboard** — active bookings, guests in house, revenue, cash to collect, refunds, and tonight's occupancy per room type.
- **Guests** — search, details, block (with reason, optionally cancelling their upcoming bookings) and unblock.
- **Reservations** — all bookings; **Check In**, **Check Out**, **Cancel** (with fee waiver option).
- **Payments** — all payments, totals, **Mark as Paid** for cash.
- **Rooms** — change price, max guests and number of rooms per type (cannot go below what is already booked).

## GUI Designer forms
Every screen has a `.form` file in `src/ui/`.
- **Driven by their form** (layout lives in the `.form`; the class only adds behavior): `LoginPanel`, `PaymentsPanel`, `ProfilePanel`, `AdminDashboardPanel`, `AdminRoomsPanel`. Components are bound to fields (`binding=` in the form), the root is `rootPanel`, and the table is a "Custom Create" component made in `createUIComponents()`. Each is a plain class with `getRootPanel()`.
- **Layout files** for the remaining screens (`BrowsePanel`, `DetailsPanel`, `CheckoutPanel`, `ReservationsPanel`, `AppPanel`, `AdminPanel`, `AdminGuestsPanel`, `AdminReservationsPanel`, `AdminPaymentsPanel`, `MainFrame`): these screens are built in code because their content is dynamic (room cards, receipts), and the `.form` documents their layout. Editing those `.form` files does not change the running screen.
- If a screen throws "form was not compiled", run **Build > Rebuild Project**. In **Settings > Build, Execution, Deployment > Compiler > User Interface Designer**, "Generate GUI into" must be *Binary class files* (the default).

## Tests
`run-tests.bat` / `./run-tests.sh` (or run `test/TestRunner.java` in IntelliJ). 21 checks: pricing, card and wallet rules, hashing, validation, accounts and lockout, reset rules, availability/overlap, double-booking, cash limits, cancellation fees, check-in/out, file safety, and that every `.form` matches its Java fields. They use a temporary folder, never your real `data/`.
`test/Shots.java` renders the form-driven screens to PNG files without opening a window.

## Data files (plain text, UTF-8, fields separated by `|`)
- `users.txt` — `fullName|email|username|passwordHash|role|status|blockReason|securityQuestion|securityAnswerHash`
- `rooms.txt` — `id|name|pricePerNight|maxGuests|units|summary|description|amenity1;amenity2|imagePath`
- `reservations.txt` — `bookingId|username|guestName|contact|roomId|roomName|checkIn|checkOut|guests|addOns|payment|total|status`
- `payments.txt` — `paymentId|bookingId|username|method|reference|amount|status|timestamp|refundAmount`

Files are saved by writing a temp file and swapping it in, so a crash cannot leave a half-written file. Older files (plain-text passwords, 8-field payments) still load and are upgraded.
Room photos go in `images/` (names are set in `rooms.txt`); a missing photo shows a drawing instead.

## Project structure
```
src/Main.java        startup checks, single-instance lock, housekeeping
src/model/           User, Room, Reservation, Payment, BookingDraft
src/service/         BookingService, CancellationPolicy, PaymentService, FileHandler (accounts),
                     Room/Reservation/PaymentFileHandler, PasswordHasher, Validators, LoginGuard,
                     DataPaths, FileStore
src/ui/              screens (+ .form files), Theme, ReadOnlyTable, DateChooser
test/  tools/        tests, screenshot tool, demo-data seeder
```

## Known limitations (what we would do next)
- Data is in text files with a single-user lock. A real deployment would use a database (only the `service` layer touches files, so that is the one place to change).
- The payment gateway and e-wallet SMS are simulated. Passwords/answers are hashed, but there is no email delivery, so password recovery uses a security question.
- Money is `double`, rounded to centavos; production code would use `BigDecimal` or whole centavos.
- No walk-in booking by the admin, early check-out refunds, or room-number assignment (rooms are counted per type).
