#!/bin/sh
# Compiles the project + tests into a temp folder and runs them. Run from the project root.
set -e
OUT=$(mktemp -d)
javac -encoding UTF-8 -cp lib/forms_rt.jar -d "$OUT" $(find src -name '*.java') test/*.java
java -Djava.awt.headless=true -cp "$OUT:lib/forms_rt.jar" TestRunner
