@echo off
rem Compiles the project + tests into a temp folder and runs them. Run from the project root.
set OUT=%TEMP%\hotel-test-out
if exist "%OUT%" rmdir /s /q "%OUT%"
mkdir "%OUT%"
dir /s /b src\*.java test\*.java > "%OUT%\sources.txt"
javac -encoding UTF-8 -cp lib\forms_rt.jar -d "%OUT%" @"%OUT%\sources.txt" || exit /b 1
java -Djava.awt.headless=true -cp "%OUT%;lib\forms_rt.jar" TestRunner
