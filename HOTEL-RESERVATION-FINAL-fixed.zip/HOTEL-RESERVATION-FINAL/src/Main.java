import service.BookingService;
import service.DataPaths;
import service.FileHandler;
import ui.MainFrame;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import java.io.File;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.time.LocalDate;

public class Main {
    // kept in a field so the lock lives as long as the program runs
    private static FileLock instanceLock;

    public static void main(String[] args) {
        // 1. we must be able to find data/ - otherwise there would be no rooms and no users, silently
        if (!DataPaths.looksValid()) {
            JOptionPane.showMessageDialog(null,
                    "The hotel's data folder was not found.\n\nLooked in: " + DataPaths.dir().getAbsolutePath()
                            + "\nStart the program from the project folder (the one that contains data/ and src/),\n"
                            + "or start Java with  -Dhotel.data.dir=<path to data>.",
                    "Data Folder Missing", JOptionPane.ERROR_MESSAGE);
            return;
        }
        // 2. only one copy at a time: two copies editing the same text files would overwrite each other
        if (!lockInstance()) {
            JOptionPane.showMessageDialog(null,
                    "Triple Threat is already running on this computer.\nClose the other window first.",
                    "Already Running", JOptionPane.WARNING_MESSAGE);
            return;
        }
        // 3. housekeeping: hash any old plain-text passwords, close out finished stays
        FileHandler.migratePasswords();
        BookingService.sweep(LocalDate.now());

        // Swing programs should start on the Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            MainFrame frame = new MainFrame();
            frame.setVisible(true);
        });
    }

    private static boolean lockInstance() {
        try {
            File lockFile = DataPaths.file(".lock");
            FileChannel channel = new RandomAccessFile(lockFile, "rw").getChannel();
            instanceLock = channel.tryLock();
            return instanceLock != null;
        } catch (Exception e) {
            return true; // if locking itself is unavailable, do not stop the program from starting
        }
    }
}
