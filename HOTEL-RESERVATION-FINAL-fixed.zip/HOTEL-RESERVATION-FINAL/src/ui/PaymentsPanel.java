package ui;

import model.Payment;
import model.User;
import service.PaymentFileHandler;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import java.awt.BorderLayout;
import java.util.ArrayList;

/**
 * "Payments": the logged-in guest's payment history from data/payments.txt.
 *
 * GUI DESIGNER: bound to PaymentsPanel.form. The layout (title, the three summary boxes, the table's
 * scroll pane) is in the .form file. The table itself is a "custom create" component: the designer
 * calls createUIComponents() below to make it. AppPanel shows getRootPanel().
 */
public class PaymentsPanel {

    private final User user;

    // ---- bound to PaymentsPanel.form
    private JPanel rootPanel;
    private JLabel paidVal;
    private JLabel dueVal;
    private JLabel refundVal;
    private JScrollPane tableScroll;
    private ReadOnlyTable table; // custom create

    public PaymentsPanel(User user) {
        this.user = user;
        init();
    }

    public JPanel getRootPanel() {
        return rootPanel;
    }

    /** called by the GUI Designer's generated code for components marked "Custom Create" in the form */
    private void createUIComponents() {
        table = new ReadOnlyTable(
                new String[]{"Payment ID", "Booking ID", "Method", "Reference", "Amount", "Refunded", "Status", "Date"},
                new int[]{95, 95, 120, 125, 80, 95, 80, 110});
    }

    private void init() {
        if (rootPanel == null) {
            throw new IllegalStateException("PaymentsPanel.form was not compiled. In IntelliJ use Build > Rebuild Project.");
        }
        ReadOnlyTable.styleScrollPane(tableScroll);
        table.statusColumn(6);
        table.alignRight(4);
        table.alignRight(5);
        for (JLabel value : new JLabel[]{paidVal, dueVal, refundVal}) {
            value.setHorizontalAlignment(SwingConstants.CENTER);
        }
    }

    /** A small summary box: big number on top, caption below (used by the admin payments page, which is still built in code) */
    static JPanel statCard(String caption, JLabel value, java.awt.Color color) {
        value.setFont(Theme.HEADING);
        value.setForeground(color);
        JLabel cap = new JLabel(caption, SwingConstants.CENTER);
        cap.setFont(Theme.LABEL.deriveFont(12f));
        JPanel card = new JPanel(new BorderLayout(0, 2));
        card.setBackground(Theme.CARD);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Theme.BORDER),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        card.add(value, BorderLayout.CENTER);
        card.add(cap, BorderLayout.SOUTH);
        return card;
    }

    /** Called by AppPanel every time this page is shown. FILE READING: data/payments.txt */
    public void refresh() {
        table.clear();
        double paid = 0;
        double due = 0;
        double refunded = 0;

        ArrayList<Payment> mine = PaymentFileHandler.loadForUser(user.getUsername());
        for (int i = mine.size() - 1; i >= 0; i--) { // newest first
            Payment p = mine.get(i);
            table.model().addRow(new Object[]{p.getPaymentId(), p.getBookingId(), p.getMethod(),
                    p.getReference(), Theme.money(p.getAmount()),
                    Payment.REFUNDED.equals(p.getStatus()) ? Theme.money(p.getRefundAmount()) : "-",
                    p.getStatus(), p.getDisplayDate()});
            if (Payment.PAID.equals(p.getStatus())) {
                paid += p.getAmount();
            } else if (Payment.PENDING.equals(p.getStatus())) {
                due += p.getAmount();
            } else if (Payment.REFUNDED.equals(p.getStatus())) {
                refunded += p.getRefundAmount();
                paid += p.getRetained(); // a late-cancellation fee the hotel kept is money the guest did pay
            }
        }
        paidVal.setText(Theme.money(paid));
        dueVal.setText(Theme.money(due));
        refundVal.setText(Theme.money(refunded));
    }
}
