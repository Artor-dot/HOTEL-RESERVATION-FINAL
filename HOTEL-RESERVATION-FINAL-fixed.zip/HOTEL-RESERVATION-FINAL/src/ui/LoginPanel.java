package ui;

import model.User;
import service.FileHandler;
import service.LoginGuard;
import service.PasswordHasher;
import service.Validators;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import java.awt.CardLayout;
import java.awt.Component;

/**
 * Login / Create account / Forgot password.
 *
 * GUI DESIGNER: this screen is bound to LoginPanel.form. The layout (cards, labels, fields, buttons)
 * lives in the .form file; IntelliJ builds it when you compile and fills every field below that is
 * not assigned here (rootPanel, loginUser, ...). This class only adds behavior (styling + listeners).
 * To change the layout, open LoginPanel.form in IntelliJ's designer - do not add components here.
 * MainFrame shows getRootPanel().
 */
public class LoginPanel {

    static final String[] QUESTIONS = {
            "What was the name of your first pet?",
            "What is your mother's maiden name?",
            "What was the name of your primary school?",
            "In what city were you born?",
            "What was your childhood nickname?"
    };

    private final MainFrame frame;

    // ---- bound to LoginPanel.form (assigned by the GUI Designer, so never final and never "new" here)
    private JPanel rootPanel;
    private JPanel cardContainer;

    private JTextField loginUser;
    private JPasswordField loginPass;
    private JCheckBox showPass;
    private JButton loginBtn;
    private JButton forgotLink;
    private JButton createLink;

    private JTextField regName;
    private JTextField regEmail;
    private JTextField regUser;
    private JPasswordField regPass;
    private JPasswordField regConfirm;
    private JComboBox<String> regQuestion;
    private JTextField regAnswer;
    private JButton createBtn;
    private JButton backFromCreate;

    private JTextField resetUser;
    private JTextField resetEmail;
    private JButton showQuestionBtn;
    private JLabel resetQuestion;
    private JTextField resetAnswer;
    private JPasswordField resetNew;
    private JPasswordField resetConfirm;
    private JButton resetBtn;
    private JButton backFromReset;

    public LoginPanel(MainFrame frame) {
        this.frame = frame;
        init();
    }

    /** the screen the frame puts on its CardLayout */
    public JPanel getRootPanel() {
        return rootPanel;
    }

    private void init() {
        if (rootPanel == null) {
            throw new IllegalStateException("LoginPanel.form was not compiled. In IntelliJ use Build > Rebuild Project.");
        }
        Theme.styleGold(loginBtn);
        Theme.styleGold(createBtn);
        Theme.styleGold(resetBtn);
        for (JButton link : new JButton[]{forgotLink, createLink, backFromCreate, backFromReset, showQuestionBtn}) {
            Theme.styleLink(link);
        }
        regQuestion.setModel(new DefaultComboBoxModel<>(QUESTIONS));

        showPass.addActionListener(e -> loginPass.setEchoChar(showPass.isSelected() ? (char) 0 : '\u2022'));
        loginBtn.addActionListener(e -> doLogin());
        createBtn.addActionListener(e -> doCreateAccount());
        resetBtn.addActionListener(e -> doResetPassword());
        showQuestionBtn.addActionListener(e -> doShowQuestion());

        forgotLink.addActionListener(e -> show("RESET", resetUser));
        createLink.addActionListener(e -> show("CREATE", regName));
        backFromCreate.addActionListener(e -> show("LOGIN", loginUser));
        backFromReset.addActionListener(e -> show("LOGIN", loginUser));

        // pressing Enter in the last field submits the form
        loginPass.addActionListener(e -> doLogin());
        regAnswer.addActionListener(e -> doCreateAccount());
        resetConfirm.addActionListener(e -> doResetPassword());

        show("LOGIN", loginUser);
    }

    private void show(String card, Component focus) {
        ((CardLayout) cardContainer.getLayout()).show(cardContainer, card);
        focus.requestFocusInWindow();
    }

    // ------------------------------------------------------------ login

    private void doLogin() {
        String username = loginUser.getText().trim();
        String password = new String(loginPass.getPassword());

        if (username.isEmpty() || password.isEmpty()) {
            warn("Missing Information", "Please enter your username and password.");
            return;
        }
        long locked = LoginGuard.secondsLocked(username);
        if (locked > 0) {
            warn("Too Many Attempts", "Too many wrong passwords. Please wait " + locked + " seconds and try again.");
            return;
        }

        User user = FileHandler.login(username, password);
        if (user == null) {
            long nowLocked = LoginGuard.secondsLocked(username);
            error("Login Failed", nowLocked > 0
                    ? "Too many wrong passwords. This account is locked for " + nowLocked + " seconds."
                    : "Incorrect username or password.");
            loginPass.setText("");
            return;
        }
        if (user.isBlocked()) {
            error("Account Blocked", "This account has been blocked by the hotel administrator.\nReason: "
                    + user.getBlockReason() + "\nPlease contact the front desk if you think this is a mistake.");
            loginPass.setText("");
            return;
        }

        JOptionPane.showMessageDialog(rootPanel, "Welcome, " + user.getFullName() + "!",
                "Login Successful", JOptionPane.INFORMATION_MESSAGE);
        loginUser.setText("");
        loginPass.setText("");
        showPass.setSelected(false);
        loginPass.setEchoChar('\u2022');
        frame.showApp(user);
    }

    // ------------------------------------------------------------ create account

    private void doCreateAccount() {
        String name = regName.getText().trim();
        String email = regEmail.getText().trim();
        String username = regUser.getText().trim();
        String pass = new String(regPass.getPassword());
        String confirm = new String(regConfirm.getPassword());
        String answer = regAnswer.getText().trim();

        if (name.isEmpty() || email.isEmpty() || username.isEmpty() || pass.isEmpty() || confirm.isEmpty() || answer.isEmpty()) {
            warn("Invalid Input", "Please fill in all fields (including your security answer).");
            return;
        }
        String err = firstError(
                hasPipe(name, email, username, pass, answer) ? "The \"|\" character is not allowed." : null,
                Validators.fullName(name), Validators.email(email), Validators.username(username),
                Validators.password(pass), pass.equals(confirm) ? null : "Passwords do not match.",
                answer.length() < 2 ? "Your security answer must be at least 2 characters." : null);
        if (err != null) {
            warn("Invalid Input", err);
            return;
        }
        if (FileHandler.isEmailBlocked(email)) {
            error("Email Blocked", "This email belongs to a blocked account and cannot be used to register.");
            return;
        }
        if (FileHandler.emailExists(email)) {
            error("Email Already Used", "An account with this email already exists. Use \"Forgot Password\" if it is yours.");
            return;
        }
        if (FileHandler.usernameExists(username)) {
            error("Username Taken", "That username is already taken.");
            return;
        }

        User newUser = new User(name, email, username, PasswordHasher.hash(pass),
                (String) regQuestion.getSelectedItem(), PasswordHasher.hash(FileHandler.normalizeAnswer(answer)));
        if (FileHandler.addUser(newUser)) {
            JOptionPane.showMessageDialog(rootPanel, "Account created! You can now log in.",
                    "Success", JOptionPane.INFORMATION_MESSAGE);
            for (JTextField f : new JTextField[]{regName, regEmail, regUser, regPass, regConfirm, regAnswer}) {
                f.setText("");
            }
            loginUser.setText(username);
            show("LOGIN", loginPass);
        } else {
            error("File Error", "Could not save your account.");
        }
    }

    // ------------------------------------------------------------ forgot password

    private void doShowQuestion() {
        String username = resetUser.getText().trim();
        String email = resetEmail.getText().trim();
        if (username.isEmpty() || email.isEmpty()) {
            warn("Invalid Input", "Enter your username and registered email first.");
            return;
        }
        String q = FileHandler.securityQuestionFor(username, email);
        if (q == null) {
            resetQuestion.setText(" ");
            warn("Cannot Reset Here", "We could not find a guest account with a security question for those details.\n"
                    + "Please ask the front desk to help you (admin accounts cannot be reset here).");
            return;
        }
        resetQuestion.setText("<html>" + Theme.html(q) + "</html>");
        resetAnswer.requestFocusInWindow();
    }

    private void doResetPassword() {
        String username = resetUser.getText().trim();
        String email = resetEmail.getText().trim();
        String answer = resetAnswer.getText();
        String newPass = new String(resetNew.getPassword());
        String confirm = new String(resetConfirm.getPassword());

        if (username.isEmpty() || email.isEmpty() || answer.trim().isEmpty() || newPass.isEmpty() || confirm.isEmpty()) {
            warn("Invalid Input", "Please fill in all fields.");
            return;
        }
        if (hasPipe(newPass)) {
            warn("Invalid Input", "The \"|\" character is not allowed.");
            return;
        }
        if (!newPass.equals(confirm)) {
            warn("Invalid Input", "Passwords do not match.");
            return;
        }
        String err = FileHandler.resetPassword(username, email, answer, newPass);
        if (err != null) {
            error("Reset Failed", err);
            return;
        }
        JOptionPane.showMessageDialog(rootPanel, "Password reset successful. Please log in.",
                "Success", JOptionPane.INFORMATION_MESSAGE);
        for (JTextField f : new JTextField[]{resetUser, resetEmail, resetAnswer, resetNew, resetConfirm}) {
            f.setText("");
        }
        resetQuestion.setText(" ");
        loginUser.setText(username);
        show("LOGIN", loginPass);
    }

    // ------------------------------------------------------------ helpers

    private static String firstError(String... errors) {
        for (String e : errors) {
            if (e != null) {
                return e;
            }
        }
        return null;
    }

    private static boolean hasPipe(String... texts) {
        for (String t : texts) {
            if (t.contains("|")) {
                return true;
            }
        }
        return false;
    }

    private void warn(String title, String message) {
        JOptionPane.showMessageDialog(rootPanel, message, title, JOptionPane.WARNING_MESSAGE);
    }

    private void error(String title, String message) {
        JOptionPane.showMessageDialog(rootPanel, message, title, JOptionPane.ERROR_MESSAGE);
    }
}
