package ui;

import model.Payment;
import model.Reservation;
import model.Room;
import service.PaymentFileHandler;
import service.ReservationFileHandler;
import service.RoomFileHandler;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import java.time.LocalDate;
import java.util.List;

/**
 * Admin "Dashboard": the numbers a manager looks at first.
 * GUI DESIGNER: bound to AdminDashboardPanel.form (summary boxes + occupancy table).
 */
public class AdminDashboardPanel {

    // ---- bound to AdminDashboardPanel.form
    private JPanel rootPanel;
    private JLabel activeVal;
    private JLabel inHouseVal;
    private JLabel revenueVal;
    private JLabel pendingVal;
    private JLabel refundVal;
    private JScrollPane tableScroll;
    private ReadOnlyTable table; // custom create

    public AdminDashboardPanel() {
        init();
    }

    public JPanel getRootPanel() {
        return rootPanel;
    }

    private void createUIComponents() {
        table = new ReadOnlyTable(new String[]{"Room type", "Rooms", "Occupied tonight", "Free tonight", "Upcoming bookings"},
                new int[]{200, 70, 140, 110, 140});
    }

    private void init() {
        if (rootPanel == null) {
            throw new IllegalStateException("AdminDashboardPanel.form was not compiled. In IntelliJ use Build > Rebuild Project.");
        }
        ReadOnlyTable.styleScrollPane(tableScroll);
        table.alignRight(1);
        table.alignRight(2);
        table.alignRight(3);
        table.alignRight(4);
    }

    /** FILE READING: reservations, payments and rooms */
    public void refresh() {
        LocalDate today = LocalDate.now();
        List<Reservation> all = ReservationFileHandler.loadAll();
        int active = 0;
        int inHouse = 0;
        for (Reservation r : all) {
            if (r.isActive()) {
                active++;
            }
            if (Reservation.CHECKED_IN.equals(r.getStatus())) {
                inHouse += r.getGuests();
            }
        }
        double revenue = 0;
        double pending = 0;
        double refunded = 0;
        for (Payment p : PaymentFileHandler.loadAll()) {
            if (Payment.PAID.equals(p.getStatus())) {
                revenue += p.getAmount();
            } else if (Payment.PENDING.equals(p.getStatus())) {
                pending += p.getAmount();
            } else if (Payment.REFUNDED.equals(p.getStatus())) {
                revenue += p.getRetained();
                refunded += p.getRefundAmount();
            }
        }
        activeVal.setText(String.valueOf(active));
        inHouseVal.setText(String.valueOf(inHouse));
        revenueVal.setText(Theme.money(revenue));
        pendingVal.setText(Theme.money(pending));
        refundVal.setText(Theme.money(refunded));

        table.clear();
        for (Room room : RoomFileHandler.loadRooms()) {
            int free = ReservationFileHandler.roomsLeft(room, today, today.plusDays(1), all);
            int upcoming = 0;
            for (Reservation r : all) {
                if (r.getRoomId().equals(room.getId()) && Reservation.CONFIRMED.equals(r.getStatus())
                        && !r.getCheckIn().isBefore(today)) {
                    upcoming++;
                }
            }
            table.model().addRow(new Object[]{room.getName(), room.getUnits(), room.getUnits() - free, free, upcoming});
        }
    }
}
