package ui;

import model.Room;
import service.BookingService;
import service.RoomFileHandler;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 * Admin "Rooms": change the price, guest limit and number of rooms of each room type (writes data/rooms.txt).
 * GUI DESIGNER: bound to AdminRoomsPanel.form (table + edit row).
 */
public class AdminRoomsPanel {

    // ---- bound to AdminRoomsPanel.form
    private JPanel rootPanel;
    private JScrollPane tableScroll;
    private ReadOnlyTable table; // custom create
    private JLabel selectedLabel;
    private JTextField priceField;
    private JTextField guestsField;
    private JTextField unitsField;
    private JButton saveBtn;

    private ArrayList<Room> rooms = new ArrayList<>();

    public AdminRoomsPanel() {
        init();
    }

    public JPanel getRootPanel() {
        return rootPanel;
    }

    private void createUIComponents() {
        table = new ReadOnlyTable(new String[]{"ID", "Room type", "Price / night", "Max guests", "Rooms"},
                new int[]{70, 260, 120, 100, 80});
    }

    private void init() {
        if (rootPanel == null) {
            throw new IllegalStateException("AdminRoomsPanel.form was not compiled. In IntelliJ use Build > Rebuild Project.");
        }
        ReadOnlyTable.styleScrollPane(tableScroll);
        table.alignRight(2);
        table.alignRight(3);
        table.alignRight(4);
        Theme.styleGold(saveBtn);
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                fillFields();
            }
        });
        saveBtn.addActionListener(e -> save());
    }

    /** FILE READING: data/rooms.txt */
    public void refresh() {
        rooms = RoomFileHandler.loadRooms();
        table.clear();
        for (Room r : rooms) {
            table.model().addRow(new Object[]{r.getId(), r.getName(), Theme.money(r.getPricePerNight()),
                    r.getMaxGuests(), r.getUnits()});
        }
        selectedLabel.setText("(select a row)");
        priceField.setText("");
        guestsField.setText("");
        unitsField.setText("");
    }

    private Room selected() {
        int row = table.getSelectedRow();
        return row >= 0 && row < rooms.size() ? rooms.get(row) : null;
    }

    private void fillFields() {
        Room r = selected();
        if (r == null) {
            return;
        }
        selectedLabel.setText(r.getName());
        priceField.setText(String.format("%.0f", r.getPricePerNight()));
        guestsField.setText(String.valueOf(r.getMaxGuests()));
        unitsField.setText(String.valueOf(r.getUnits()));
    }

    private void save() {
        Room r = selected();
        if (r == null) {
            warn("Please select a room type in the table first.");
            return;
        }
        double price;
        int guests;
        int units;
        try {
            price = Double.parseDouble(priceField.getText().trim());
            guests = Integer.parseInt(guestsField.getText().trim());
            units = Integer.parseInt(unitsField.getText().trim());
        } catch (NumberFormatException ex) {
            warn("Price, max guests and rooms must be numbers.");
            return;
        }
        if (price < 100 || price > 1_000_000) {
            warn("Price per night must be between \u20B1100 and \u20B11,000,000.");
            return;
        }
        if (guests < 1 || guests > 10) {
            warn("Max guests must be between 1 and 10.");
            return;
        }
        if (units < 1 || units > 100) {
            warn("Rooms of this type must be between 1 and 100.");
            return;
        }
        int booked = BookingService.maxBookedAtOnce(r.getId(), LocalDate.now());
        if (units < booked) {
            warn("Cannot go below " + booked + " room(s): that many are already booked on the same night.\n"
                    + "Cancel or move those bookings first.");
            return;
        }
        ArrayList<Room> updated = new ArrayList<>();
        for (Room old : RoomFileHandler.loadRooms()) {
            updated.add(old.getId().equals(r.getId())
                    ? new Room(old.getId(), old.getName(), price, guests, units, old.getSummary(),
                    old.getDescription(), old.getAmenities(), old.getImagePath())
                    : old);
        }
        if (!RoomFileHandler.saveRooms(updated)) { // FILE WRITING
            JOptionPane.showMessageDialog(rootPanel, "Could not save rooms.txt.", "File Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        refresh();
        JOptionPane.showMessageDialog(rootPanel, "Saved. New bookings will use these values.", "Rooms", JOptionPane.INFORMATION_MESSAGE);
    }

    private void warn(String message) {
        JOptionPane.showMessageDialog(rootPanel, message, "Check Input", JOptionPane.WARNING_MESSAGE);
    }
}
