package ui;

import model.Payment;
import model.Reservation;
import service.BookingService;
import service.CancellationPolicy;
import service.PaymentFileHandler;
import service.ReservationFileHandler;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

/** Admin: every reservation from every guest, with the option to cancel one (payment is refunded / voided). */
public class AdminReservationsPanel extends JPanel {

    private final ReadOnlyTable table = new ReadOnlyTable(
            new String[]{"Booking ID", "Guest", "Room", "Check-In", "Check-Out", "Total", "Payment", "Status"},
            new int[]{100, 140, 115, 80, 80, 80, 70, 80});
    private final ArrayList<Reservation> shown = new ArrayList<>();
    private final JTextField search = new JTextField();
    private final JLabel infoLabel = new JLabel(" ");

    public AdminReservationsPanel() {
        setLayout(new BorderLayout(0, 10));
        setBackground(Theme.CREAM);
        setBorder(BorderFactory.createEmptyBorder(25, 25, 20, 25));

        JPanel top = new JPanel(new BorderLayout(0, 10));
        top.setOpaque(false);
        top.add(Theme.title("ALL RESERVATIONS"), BorderLayout.NORTH);
        top.add(Theme.searchRow(search), BorderLayout.CENTER);
        add(top, BorderLayout.NORTH);

        table.statusColumn(6);
        table.statusColumn(7);
        table.alignRight(5);
        add(table.inScrollPane(), BorderLayout.CENTER);

        JButton checkIn = Theme.goldButton("CHECK IN");
        checkIn.setPreferredSize(new java.awt.Dimension(110, 38));
        checkIn.addActionListener(e -> checkInSelected());
        JButton checkOut = Theme.goldButton("CHECK OUT");
        checkOut.setPreferredSize(new java.awt.Dimension(115, 38));
        checkOut.addActionListener(e -> checkOutSelected());
        JButton cancel = Theme.dangerButton("CANCEL RESERVATION");
        cancel.setPreferredSize(new java.awt.Dimension(190, 38));
        cancel.addActionListener(e -> cancelSelected());
        JButton refresh = Theme.outlineButton("REFRESH");
        refresh.setPreferredSize(new java.awt.Dimension(110, 38));
        refresh.addActionListener(e -> refresh());
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        buttons.setOpaque(false);
        buttons.add(refresh);
        buttons.add(checkIn);
        buttons.add(checkOut);
        buttons.add(cancel);
        JPanel south = new JPanel(new BorderLayout());
        south.setOpaque(false);
        infoLabel.setFont(Theme.LABEL);
        south.add(infoLabel, BorderLayout.WEST);
        south.add(buttons, BorderLayout.EAST);
        add(south, BorderLayout.SOUTH);

        Theme.onTextChange(search, this::refresh);
    }

    /** Called by AdminPanel every time this page is shown. FILE READING: reservations + payments */
    public void refresh() {
        BookingService.sweep(LocalDate.now()); // stays that ended become NO_SHOW / COMPLETED
        String q = search.getText().trim().toLowerCase();
        HashMap<String, Payment> payments = new HashMap<>();
        for (Payment p : PaymentFileHandler.loadAll()) {
            payments.put(p.getBookingId(), p);
        }

        table.clear();
        shown.clear();
        ArrayList<Reservation> all = ReservationFileHandler.loadAll();
        int confirmed = 0;
        for (int i = all.size() - 1; i >= 0; i--) { // newest first
            Reservation r = all.get(i);
            if (r.isActive()) {
                confirmed++;
            }
            String haystack = (r.getBookingId() + " " + r.getGuestName() + " " + r.getUsername()
                    + " " + r.getRoomName()).toLowerCase();
            if (!q.isEmpty() && !haystack.contains(q)) {
                continue;
            }
            Payment p = payments.get(r.getBookingId());
            shown.add(r);
            table.model().addRow(new Object[]{r.getBookingId(),
                    r.getGuestName() + " (" + r.getUsername() + ")", r.getRoomName(),
                    r.getCheckIn(), r.getCheckOut(), Theme.money(r.getTotal()),
                    p == null ? "-" : p.getStatus(), r.getStatus()});
        }
        infoLabel.setText(all.size() + " reservations, " + confirmed + " active");
    }

    private Reservation selected() {
        int row = table.getSelectedRow();
        if (row < 0 || row >= shown.size()) {
            JOptionPane.showMessageDialog(this, "Please select a reservation first.",
                    "No Selection", JOptionPane.INFORMATION_MESSAGE);
            return null;
        }
        return shown.get(row);
    }

    private void checkInSelected() {
        Reservation r = selected();
        if (r == null) {
            return;
        }
        Payment p = PaymentFileHandler.findByBooking(r.getBookingId());
        boolean collected = false;
        if (p != null && Payment.PENDING.equals(p.getStatus())) {
            int c = JOptionPane.showConfirmDialog(this,
                    "Cash payment is still pending.\nHave you collected " + Theme.money(p.getAmount()) + " from " + r.getGuestName() + "?",
                    "Collect Payment", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (c != JOptionPane.YES_OPTION) {
                return;
            }
            collected = true;
        }
        show(BookingService.checkIn(r, collected));
    }

    private void checkOutSelected() {
        Reservation r = selected();
        if (r != null) {
            show(BookingService.checkOut(r));
        }
    }

    private void show(BookingService.CancelResult result) {
        refresh();
        JOptionPane.showMessageDialog(this, result.message, result.ok ? "Done" : "Not Allowed",
                result.ok ? JOptionPane.INFORMATION_MESSAGE : JOptionPane.WARNING_MESSAGE);
    }

    private void cancelSelected() {
        Reservation r = selected();
        if (r == null) {
            return;
        }
        if (!CancellationPolicy.canCancel(r, LocalDate.now(), true)) {
            JOptionPane.showMessageDialog(this, "A " + r.getStatus() + " reservation cannot be cancelled. "
                            + (r.getStatus().equals(Reservation.CHECKED_IN) ? "Use CHECK OUT instead." : ""),
                    "Cannot Cancel", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String head = "Cancel booking " + r.getBookingId() + " of " + r.getGuestName() + "?\n\n";
        boolean late = CancellationPolicy.isLate(r, LocalDate.now())
                && CancellationPolicy.fee(r, r.getTotal(), LocalDate.now(), false) > 0
                && Payment.PAID.equals(paymentStatus(r));
        boolean waive = false;
        if (late) {
            Object[] options = {"Cancel (keep fee)", "Cancel and waive fee", "Keep booking"};
            int c = JOptionPane.showOptionDialog(this, head + BookingService.cancelPreview(r, false),
                    "Late Cancellation", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, null, options, options[2]);
            if (c != 0 && c != 1) {
                return;
            }
            waive = c == 1;
        } else {
            int c = JOptionPane.showConfirmDialog(this, head + BookingService.cancelPreview(r, false),
                    "Cancel Reservation", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (c != JOptionPane.YES_OPTION) {
                return;
            }
        }
        show(BookingService.cancel(r, true, waive)); // FILE WRITING
    }

    private String paymentStatus(Reservation r) {
        Payment p = PaymentFileHandler.findByBooking(r.getBookingId());
        return p == null ? "" : p.getStatus();
    }
}
