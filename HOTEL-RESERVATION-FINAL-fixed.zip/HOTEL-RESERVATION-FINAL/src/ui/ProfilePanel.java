package ui;

import model.User;
import service.FileHandler;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 * "Profile": edit your name / email, change your password, and set the security question that
 * the "Forgot Password" screen uses.
 *
 * GUI DESIGNER: bound to ProfilePanel.form (all fields below are created by the form).
 * AppPanel shows getRootPanel().
 */
public class ProfilePanel {

    private final User user;

    // ---- bound to ProfilePanel.form
    private JPanel rootPanel;
    private JLabel usernameVal;
    private JTextField nameField;
    private JTextField emailField;
    private JButton saveProfileBtn;
    private JPasswordField curPass;
    private JPasswordField newPass;
    private JPasswordField confPass;
    private JButton changePassBtn;
    private JLabel securityStatus;
    private JComboBox<String> questionBox;
    private JTextField answerField;
    private JPasswordField secPass;
    private JButton saveSecurityBtn;

    public ProfilePanel(User user) {
        this.user = user;
        init();
    }

    public JPanel getRootPanel() {
        return rootPanel;
    }

    private void init() {
        if (rootPanel == null) {
            throw new IllegalStateException("ProfilePanel.form was not compiled. In IntelliJ use Build > Rebuild Project.");
        }
        Theme.styleGold(saveProfileBtn);
        Theme.styleGold(changePassBtn);
        Theme.styleGold(saveSecurityBtn);
        questionBox.setModel(new DefaultComboBoxModel<>(LoginPanel.QUESTIONS));

        saveProfileBtn.addActionListener(e -> saveProfile());
        changePassBtn.addActionListener(e -> changePassword());
        saveSecurityBtn.addActionListener(e -> saveSecurity());
    }

    /** Called by AppPanel every time this page is shown. FILE READING: data/users.txt */
    public void refresh() {
        User fresh = FileHandler.findByUsername(user.getUsername());
        if (fresh == null) {
            return;
        }
        usernameVal.setText(fresh.getUsername());
        nameField.setText(fresh.getFullName());
        emailField.setText(fresh.getEmail());
        securityStatus.setText(fresh.hasSecurityQuestion()
                ? "<html>A security question is set. Choose a new one to replace it.</html>"
                : "<html><font color='#8B2E2E'>Not set.</font> Without one you cannot reset your password yourself.</html>");
        for (JPasswordField f : new JPasswordField[]{curPass, newPass, confPass, secPass}) {
            f.setText("");
        }
        answerField.setText("");
    }

    private void saveProfile() {
        String name = nameField.getText().trim();
        String email = emailField.getText().trim();
        if (name.contains("|") || email.contains("|")) {
            info("The \"|\" character is not allowed.", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String err = FileHandler.updateProfile(user.getUsername(), name, email); // FILE WRITING
        if (err != null) {
            info(err, JOptionPane.WARNING_MESSAGE);
            return;
        }
        user.setFullName(name);
        user.setEmail(email);
        info("Your details were saved.", JOptionPane.INFORMATION_MESSAGE);
    }

    private void changePassword() {
        String cur = new String(curPass.getPassword());
        String neu = new String(newPass.getPassword());
        if (cur.isEmpty() || neu.isEmpty()) {
            info("Please fill in your current and new password.", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (!neu.equals(new String(confPass.getPassword()))) {
            info("The new passwords do not match.", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (neu.contains("|")) {
            info("The \"|\" character is not allowed.", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String err = FileHandler.changePassword(user.getUsername(), cur, neu); // FILE WRITING
        if (err != null) {
            info(err, JOptionPane.WARNING_MESSAGE);
            return;
        }
        for (JPasswordField f : new JPasswordField[]{curPass, newPass, confPass}) {
            f.setText("");
        }
        info("Your password was changed.", JOptionPane.INFORMATION_MESSAGE);
    }

    private void saveSecurity() {
        String answer = answerField.getText();
        if (answer.contains("|")) {
            info("The \"|\" character is not allowed.", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String err = FileHandler.setSecurityQuestion(user.getUsername(), new String(secPass.getPassword()),
                (String) questionBox.getSelectedItem(), answer); // FILE WRITING
        if (err != null) {
            info(err, JOptionPane.WARNING_MESSAGE);
            return;
        }
        refresh();
        info("Your security question was saved.", JOptionPane.INFORMATION_MESSAGE);
    }

    private void info(String message, int type) {
        JOptionPane.showMessageDialog(rootPanel, message, "Profile", type);
    }
}
