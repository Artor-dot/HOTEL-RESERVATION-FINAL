package model;

/**
 * A guest or admin account.
 * Line format in data/users.txt:
 * fullName|email|username|passwordHash|role|status|blockReason|securityQuestion|securityAnswerHash
 * (older 4-field and 7-field lines still load)
 */
public class User {
    public static final String GUEST = "GUEST";
    public static final String ADMIN = "ADMIN";

    private String fullName;
    private String email;
    private final String username;
    private String password;      // PBKDF2 hash (see service.PasswordHasher)
    private final String role;
    private boolean blocked;
    private String blockReason;
    private String secQuestion;   // "" = none set (account cannot use self-service reset)
    private String secAnswer;     // hashed, normalized answer

    public User(String fullName, String email, String username, String password,
                String role, boolean blocked, String blockReason, String secQuestion, String secAnswer) {
        this.fullName = fullName;
        this.email = email;
        this.username = username;
        this.password = password;
        this.role = role;
        this.blocked = blocked;
        this.blockReason = blockReason;
        this.secQuestion = secQuestion;
        this.secAnswer = secAnswer;
    }

    public User(String fullName, String email, String username, String password,
                String role, boolean blocked, String blockReason) {
        this(fullName, email, username, password, role, blocked, blockReason, "", "");
    }

    /** normal sign-up: an active guest (password and answer must already be hashed) */
    public User(String fullName, String email, String username, String passwordHash,
                String secQuestion, String secAnswerHash) {
        this(fullName, email, username, passwordHash, GUEST, false, "", secQuestion, secAnswerHash);
    }

    public String getFullName() { return fullName; }
    public String getEmail() { return email; }
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public String getRole() { return role; }
    public boolean isAdmin() { return ADMIN.equals(role); }
    public boolean isBlocked() { return blocked; }
    public String getBlockReason() { return blockReason; }
    public String getSecQuestion() { return secQuestion; }
    public String getSecAnswer() { return secAnswer; }
    public boolean hasSecurityQuestion() { return !secQuestion.isEmpty() && !secAnswer.isEmpty(); }

    public void setPassword(String password) { this.password = password; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public void setEmail(String email) { this.email = email; }

    public void setSecurity(String question, String answerHash) {
        this.secQuestion = question;
        this.secAnswer = answerHash;
    }

    public void setBlocked(boolean blocked, String reason) {
        this.blocked = blocked;
        this.blockReason = blocked ? reason : "";
    }

    public String toFileLine() {
        return String.join("|", fullName, email, username, password, role,
                blocked ? "BLOCKED" : "ACTIVE", blockReason, secQuestion, secAnswer);
    }
}
