package service;

import model.Room;

import java.io.File;
import java.util.ArrayList;
import java.util.Locale;

/**
 * Reads and writes data/rooms.txt
 * Format per line:  id|name|pricePerNight|maxGuests|units|summary|description|amenity1;amenity2;...|imagePath
 */
public class RoomFileHandler {

    public static File roomsFile() {
        return DataPaths.file("rooms.txt");
    }

    private static final String HEADER =
            "# id|name|pricePerNight (pesos)|maxGuests|units (rooms the hotel has)|summary|description|amenities (separated by ;)|imagePath";

    // FILE READING: load every room from the text file
    public static ArrayList<Room> loadRooms() {
        ArrayList<Room> rooms = new ArrayList<>();
        synchronized (FileStore.LOCK) {
            for (String line : FileStore.readLines(roomsFile())) {
                if (line.startsWith("#")) {
                    continue;
                }
                String[] p = line.split("\\|", -1);
                if (p.length != 9) {
                    continue;
                }
                try {
                    rooms.add(new Room(p[0], p[1], Double.parseDouble(p[2]), Integer.parseInt(p[3]),
                            Integer.parseInt(p[4]), p[5], p[6], p[7].split(";"), p[8]));
                } catch (NumberFormatException e) {
                    System.out.println("Skipping bad room line: " + line);
                }
            }
        }
        return rooms;
    }

    public static Room findById(String id) {
        for (Room r : loadRooms()) {
            if (r.getId().equals(id)) {
                return r;
            }
        }
        return null;
    }

    /** FILE WRITING (admin "Rooms" page): rewrites rooms.txt, keeping the header line. */
    public static boolean saveRooms(ArrayList<Room> rooms) {
        ArrayList<String> lines = new ArrayList<>();
        lines.add(HEADER);
        for (Room r : rooms) {
            lines.add(String.join("|", r.getId(), r.getName(),
                    String.format(Locale.US, "%.0f", r.getPricePerNight()),
                    String.valueOf(r.getMaxGuests()), String.valueOf(r.getUnits()),
                    r.getSummary(), r.getDescription(), String.join(";", r.getAmenities()), r.getImagePath()));
        }
        synchronized (FileStore.LOCK) {
            return FileStore.writeLines(roomsFile(), lines);
        }
    }
}
