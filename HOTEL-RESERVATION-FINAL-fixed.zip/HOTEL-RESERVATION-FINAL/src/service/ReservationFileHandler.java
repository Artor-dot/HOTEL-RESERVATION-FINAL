package service;

import model.Reservation;
import model.Room;

import java.io.File;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

/** Reads and writes data/reservations.txt (format is documented in model/Reservation.java) */
public class ReservationFileHandler {

    public static File reservationsFile() {
        return DataPaths.file("reservations.txt");
    }

    // FILE READING
    public static ArrayList<Reservation> loadAll() {
        ArrayList<Reservation> list = new ArrayList<>();
        synchronized (FileStore.LOCK) {
            for (String line : FileStore.readLines(reservationsFile())) {
                Reservation r = Reservation.fromLine(line);
                if (r != null) {
                    list.add(r);
                }
            }
        }
        return list;
    }

    // FILE WRITING: overwrite the file with the current list (atomic)
    public static boolean saveAll(ArrayList<Reservation> list) {
        ArrayList<String> lines = new ArrayList<>();
        for (Reservation r : list) {
            lines.add(r.toFileLine());
        }
        synchronized (FileStore.LOCK) {
            return FileStore.writeLines(reservationsFile(), lines);
        }
    }

    public static boolean addReservation(Reservation r) {
        synchronized (FileStore.LOCK) {
            ArrayList<Reservation> list = loadAll();
            list.add(r);
            return saveAll(list);
        }
    }

    public static boolean remove(String bookingId) {
        synchronized (FileStore.LOCK) {
            ArrayList<Reservation> list = loadAll();
            if (!list.removeIf(r -> r.getBookingId().equals(bookingId))) {
                return false;
            }
            return saveAll(list);
        }
    }

    public static Reservation findById(String bookingId) {
        for (Reservation r : loadAll()) {
            if (r.getBookingId().equals(bookingId)) {
                return r;
            }
        }
        return null;
    }

    public static ArrayList<Reservation> loadForUser(String username) {
        ArrayList<Reservation> mine = new ArrayList<>();
        for (Reservation r : loadAll()) {
            if (r.getUsername().equalsIgnoreCase(username)) {
                mine.add(r);
            }
        }
        return mine;
    }

    /**
     * How many units of this room type are still free for every night in [checkIn, checkOut).
     * Confirmed, checked-in and completed bookings use up a unit; cancelled / no-show ones don't.
     */
    public static int roomsLeft(Room room, LocalDate checkIn, LocalDate checkOut) {
        return roomsLeft(room, checkIn, checkOut, loadAll());
    }

    /**
     * Same, but with the reservation list passed in, so a screen that checks many rooms
     * reads the file ONCE instead of once per room. One pass over the bookings (not one per night).
     */
    public static int roomsLeft(Room room, LocalDate checkIn, LocalDate checkOut, List<Reservation> all) {
        int nights = (int) ChronoUnit.DAYS.between(checkIn, checkOut);
        if (nights <= 0) {
            return room.getUnits();
        }
        int[] used = new int[nights];
        for (Reservation r : all) {
            if (!r.getRoomId().equals(room.getId()) || !r.occupiesRoom()) {
                continue;
            }
            LocalDate from = r.getCheckIn().isAfter(checkIn) ? r.getCheckIn() : checkIn;
            LocalDate to = r.getCheckOut().isBefore(checkOut) ? r.getCheckOut() : checkOut;
            for (LocalDate d = from; d.isBefore(to); d = d.plusDays(1)) {
                used[(int) ChronoUnit.DAYS.between(checkIn, d)]++;
            }
        }
        int mostUsed = 0;
        for (int u : used) {
            mostUsed = Math.max(mostUsed, u);
        }
        return Math.max(0, room.getUnits() - mostUsed);
    }

    public static boolean isRoomAvailable(Room room, LocalDate checkIn, LocalDate checkOut) {
        return roomsLeft(room, checkIn, checkOut) > 0;
    }

    /** Next id like TT-2026-0001 */
    public static String nextBookingId() {
        int max = 0;
        for (Reservation r : loadAll()) {
            String id = r.getBookingId();
            try {
                max = Math.max(max, Integer.parseInt(id.substring(id.lastIndexOf('-') + 1)));
            } catch (NumberFormatException e) {
                // ignore ids we can't read
            }
        }
        return String.format("TT-%d-%04d", LocalDate.now().getYear(), max + 1);
    }

    /** Changes one reservation's status. */
    public static boolean setStatus(String bookingId, String status) {
        synchronized (FileStore.LOCK) {
            ArrayList<Reservation> list = loadAll();
            for (Reservation r : list) {
                if (r.getBookingId().equals(bookingId)) {
                    r.setStatus(status);
                    return saveAll(list);
                }
            }
        }
        return false;
    }

    public static boolean cancel(String bookingId) {
        return setStatus(bookingId, Reservation.CANCELLED);
    }
}
