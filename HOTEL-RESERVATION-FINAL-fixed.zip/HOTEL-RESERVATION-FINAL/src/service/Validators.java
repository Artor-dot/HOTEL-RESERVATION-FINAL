package service;

import java.util.regex.Pattern;

/** Input rules shared by sign-up, profile and checkout. Each returns null when OK, else a message. */
public final class Validators {
    private static final Pattern EMAIL = Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*\\.[A-Za-z]{2,}$");
    private static final Pattern USERNAME = Pattern.compile("^[A-Za-z0-9_.]{3,20}$");
    private static final Pattern NAME = Pattern.compile("^\\p{L}[\\p{L} .'-]{1,59}$");
    private static final Pattern PHONE = Pattern.compile("^(09|\\+639)\\d{9}$");

    private Validators() { }

    public static String email(String s) {
        return EMAIL.matcher(s.trim()).matches() ? null : "Please enter a valid email address, e.g. name@example.com.";
    }

    public static String username(String s) {
        return USERNAME.matcher(s.trim()).matches() ? null
                : "Username must be 3-20 characters: letters, numbers, dot or underscore (no spaces).";
    }

    public static String fullName(String s) {
        return NAME.matcher(s.trim()).matches() ? null
                : "Please enter your real name (letters, spaces, . ' - only; no digits).";
    }

    public static String phone(String s) {
        return PHONE.matcher(s.replaceAll("[\\s-]", "")).matches() ? null
                : "Enter a valid mobile number, e.g. 0917 555 0194.";
    }

    public static String password(String s) {
        if (s.length() < 8) {
            return "Password must be at least 8 characters.";
        }
        boolean letter = s.chars().anyMatch(Character::isLetter);
        boolean digit = s.chars().anyMatch(Character::isDigit);
        return letter && digit ? null : "Password must contain at least one letter and one number.";
    }
}
