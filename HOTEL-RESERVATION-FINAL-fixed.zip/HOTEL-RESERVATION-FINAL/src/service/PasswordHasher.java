package service;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;

/**
 * Salted password hashing (PBKDF2-HMAC-SHA256, built into Java - no library needed).
 * Stored form:  pbkdf2$iterations$salt$hash   (Base64 never contains '|', so it is safe in our files)
 * Old plain-text values (no "pbkdf2$" prefix) are still accepted so existing files keep working,
 * and are converted by FileHandler.migratePasswords().
 */
public final class PasswordHasher {
    private static final String PREFIX = "pbkdf2$";
    private static final int ITERATIONS = 65_000;
    private static final SecureRandom RANDOM = new SecureRandom();

    private PasswordHasher() { }

    public static boolean isHashed(String stored) {
        return stored != null && stored.startsWith(PREFIX);
    }

    public static String hash(String plain) {
        byte[] salt = new byte[16];
        RANDOM.nextBytes(salt);
        byte[] h = derive(plain.toCharArray(), salt, ITERATIONS);
        return PREFIX + ITERATIONS + "$" + Base64.getEncoder().encodeToString(salt)
                + "$" + Base64.getEncoder().encodeToString(h);
    }

    public static boolean verify(String plain, String stored) {
        if (stored == null || plain == null) {
            return false;
        }
        if (!isHashed(stored)) { // legacy plain text
            return MessageDigest.isEqual(plain.getBytes(), stored.getBytes());
        }
        String[] p = stored.split("\\$");
        if (p.length != 4) {
            return false;
        }
        try {
            byte[] expected = Base64.getDecoder().decode(p[3]);
            byte[] actual = derive(plain.toCharArray(), Base64.getDecoder().decode(p[2]), Integer.parseInt(p[1]));
            return MessageDigest.isEqual(expected, actual);
        } catch (RuntimeException e) {
            return false;
        }
    }

    private static byte[] derive(char[] pw, byte[] salt, int iterations) {
        try {
            PBEKeySpec spec = new PBEKeySpec(pw, salt, iterations, 256);
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("Password hashing is not available", e);
        }
    }
}
