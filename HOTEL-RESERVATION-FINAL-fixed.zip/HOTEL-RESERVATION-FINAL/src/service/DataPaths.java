package service;

import java.io.File;

/**
 * Finds the data/ folder no matter where the program is started from.
 * (IntelliJ's "working directory" is often the OUTER folder, which used to make the
 * app silently load no users and no rooms.)  Tests can override it with
 * -Dhotel.data.dir=/some/folder or DataPaths.setDir(...).
 */
public final class DataPaths {
    private static File dir;

    private DataPaths() { }

    public static synchronized File dir() {
        if (dir == null) {
            dir = locate();
        }
        return dir;
    }

    public static synchronized void setDir(File d) {
        dir = d;
    }

    public static File file(String name) {
        return new File(dir(), name);
    }

    /** true when rooms.txt is found, i.e. we are really looking at the hotel's data folder */
    public static boolean looksValid() {
        return file("rooms.txt").isFile();
    }

    private static File locate() {
        String prop = System.getProperty("hotel.data.dir");
        if (prop != null && !prop.isBlank()) {
            return new File(prop);
        }
        File cwd = new File(System.getProperty("user.dir")).getAbsoluteFile();
        File parent = cwd.getParentFile();
        File[] candidates = {
                new File(cwd, "data"),
                new File(cwd, "HOTEL-RESERVATION-FINAL/data"),
                parent == null ? new File(cwd, "data") : new File(parent, "data"),
                parent == null ? new File(cwd, "data") : new File(parent, "HOTEL-RESERVATION-FINAL/data")
        };
        for (File c : candidates) {
            if (new File(c, "rooms.txt").isFile()) {
                return c;
            }
        }
        return new File(cwd, "data"); // not found: looksValid() will say so and Main shows a clear message
    }
}
