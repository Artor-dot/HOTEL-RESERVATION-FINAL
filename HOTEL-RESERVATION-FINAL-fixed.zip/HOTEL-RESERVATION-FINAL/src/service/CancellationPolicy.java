package service;

import model.Reservation;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 * The hotel's cancellation rules in one place (so guest screen, admin screen and README agree).
 *
 *  - A booking can be cancelled while it is still CONFIRMED and the guest has not passed check-in day.
 *  - 3 or more days before check-in: free cancellation, full refund.
 *  - Less than 3 days (including the check-in day): late-cancellation fee of ONE NIGHT'S AVERAGE
 *    CHARGE (booking total / nights) is kept; the rest is refunded. Admin can waive the fee.
 *  - Unpaid cash bookings have nothing to refund, so no fee is charged.
 */
public final class CancellationPolicy {
    public static final int FREE_CANCEL_DAYS = 3;

    private CancellationPolicy() { }

    public static boolean canCancel(Reservation r, LocalDate today, boolean byAdmin) {
        if (!Reservation.CONFIRMED.equals(r.getStatus())) {
            return false;
        }
        return byAdmin || !today.isAfter(r.getCheckIn());
    }

    public static boolean isLate(Reservation r, LocalDate today) {
        return ChronoUnit.DAYS.between(today, r.getCheckIn()) < FREE_CANCEL_DAYS;
    }

    /** Fee kept from a PAID booking if cancelled today (0 when free, capped at what was paid). */
    public static double fee(Reservation r, double amountPaid, LocalDate today, boolean waive) {
        if (waive || !isLate(r, today) || r.getNights() <= 0) {
            return 0;
        }
        double oneNight = Math.round(r.getTotal() / r.getNights() * 100.0) / 100.0;
        return Math.min(oneNight, amountPaid);
    }

    public static String describe() {
        return "Free cancellation up to " + FREE_CANCEL_DAYS + " days before check-in. After that, one night's charge is kept.";
    }
}
