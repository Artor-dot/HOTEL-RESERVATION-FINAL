package service;

import model.BookingDraft;
import model.Payment;
import model.Reservation;
import model.Room;
import model.User;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Every action that changes reservations AND payments lives here, so the two files always agree.
 * All the booking rules are checked here (not only in the screens), so no screen can skip them.
 */
public class BookingService {

    public static final int MAX_NIGHTS = 30;
    public static final int MAX_CASH_NIGHTS = 7;       // longer stays must be guaranteed by card / e-wallet
    public static final int MAX_PENDING_CASH = 2;      // unpaid cash bookings one guest may hold at once

    public static class BookResult {
        public final boolean ok;
        public final String message;
        public final Reservation reservation;
        public final Payment payment;

        BookResult(boolean ok, String message, Reservation reservation, Payment payment) {
            this.ok = ok;
            this.message = message;
            this.reservation = reservation;
            this.payment = payment;
        }
    }

    // ------------------------------------------------------------ rules

    /** All rules that depend only on the draft + guest. Returns null if OK, else the reason. */
    public static String validate(BookingDraft d, User user, LocalDate today) {
        Room room = d.getRoom();
        if (room == null) {
            return "Please choose a room first.";
        }
        if (user.isBlocked() || FileHandler.isBlocked(user.getUsername())) {
            return "This account is blocked and cannot make bookings.";
        }
        if (d.getCheckIn().isBefore(today)) {
            return "The check-in date cannot be in the past.";
        }
        if (d.nights() < 1) {
            return "Check-out must be after check-in.";
        }
        if (d.nights() > MAX_NIGHTS) {
            return "The longest stay we can book online is " + MAX_NIGHTS + " nights.";
        }
        if (d.getGuests() < 1 || d.getGuests() > room.getMaxGuests()) {
            return room.getName() + " fits at most " + room.getMaxGuests() + " guest(s).";
        }
        if (BookingDraft.PAY_CASH.equals(d.getPaymentMethod())) {
            if (d.nights() > MAX_CASH_NIGHTS) {
                return "Cash at the front desk is only available for stays up to " + MAX_CASH_NIGHTS
                        + " nights. Please pay by card or e-wallet to guarantee a longer stay.";
            }
            if (pendingCashCount(user.getUsername()) >= MAX_PENDING_CASH) {
                return "You already have " + MAX_PENDING_CASH + " unpaid cash bookings. Please pay or cancel one first, or use card / e-wallet.";
            }
        }
        return null;
    }

    public static int pendingCashCount(String username) {
        int n = 0;
        for (Payment p : PaymentFileHandler.loadForUser(username)) {
            if (Payment.PENDING.equals(p.getStatus())) {
                n++;
            }
        }
        return n;
    }

    /** This guest's active bookings that overlap the draft's dates (used for a "book another room?" warning). */
    public static List<Reservation> overlapping(String username, LocalDate in, LocalDate out) {
        ArrayList<Reservation> hits = new ArrayList<>();
        for (Reservation r : ReservationFileHandler.loadForUser(username)) {
            if (r.isActive() && in.isBefore(r.getCheckOut()) && r.getCheckIn().isBefore(out)) {
                hits.add(r);
            }
        }
        return hits;
    }

    // ------------------------------------------------------------ booking (one all-or-nothing step)

    /**
     * Saves the reservation and its payment record together. If the payment record cannot be saved,
     * the reservation is rolled back, so there is never a booking without a payment record.
     * The caller passes the approved gateway result; if this fails, NOTHING was kept.
     */
    public static BookResult book(BookingDraft d, User user, String guestName, String contact,
                                  PaymentService.Result pay) {
        synchronized (FileStore.LOCK) {
            LocalDate today = LocalDate.now();
            String err = validate(d, user, today);
            if (err != null) {
                return new BookResult(false, err, null, null);
            }
            Room room = d.getRoom();
            if (!ReservationFileHandler.isRoomAvailable(room, d.getCheckIn(), d.getCheckOut())) {
                return new BookResult(false, "Sorry, the last " + room.getName()
                        + " for those dates was just taken. Please pick other dates or another room.", null, null);
            }
            String bookingId = ReservationFileHandler.nextBookingId();
            Reservation r = new Reservation(bookingId, user.getUsername(), guestName.trim(), contact.trim(),
                    room.getId(), room.getName(), d.getCheckIn(), d.getCheckOut(), d.getGuests(),
                    String.join("; ", d.addOnLines()), d.getPaymentMethod(), d.total(), Reservation.CONFIRMED);
            if (!ReservationFileHandler.addReservation(r)) {
                return new BookResult(false, "We could not save your booking. You have not been charged. Please try again.", null, null);
            }
            Payment p = new Payment(PaymentFileHandler.nextPaymentId(), bookingId, user.getUsername(),
                    d.getPaymentMethod(), pay.reference, d.total(), pay.status, LocalDateTime.now());
            if (!PaymentFileHandler.add(p)) {
                ReservationFileHandler.remove(bookingId); // roll back
                return new BookResult(false, "We could not record your payment, so the booking was cancelled. You have not been charged. Please try again.", null, null);
            }
            return new BookResult(true, "Booking confirmed.", r, p);
        }
    }

    // ------------------------------------------------------------ cancel

    public static class CancelResult {
        public final boolean ok;
        public final String message;

        CancelResult(boolean ok, String message) {
            this.ok = ok;
            this.message = message;
        }
    }

    /** What the guest would get back if they cancelled right now (for the confirmation dialog). */
    public static String cancelPreview(Reservation r, boolean waiveFee) {
        Payment p = PaymentFileHandler.findByBooking(r.getBookingId());
        if (p == null || !Payment.PAID.equals(p.getStatus())) {
            return "Nothing has been paid, so there is nothing to refund and no fee.";
        }
        double fee = CancellationPolicy.fee(r, p.getAmount(), LocalDate.now(), waiveFee);
        return String.format(Locale.US, "Paid: \u20B1%,.2f%nCancellation fee: \u20B1%,.2f%nRefund: \u20B1%,.2f",
                p.getAmount(), fee, p.getAmount() - fee);
    }

    /**
     * Cancels a reservation and settles its payment:
     * PAID -> REFUNDED (minus any late fee), PENDING (cash not collected) -> VOID.
     */
    public static CancelResult cancel(Reservation stale, boolean byAdmin, boolean waiveFee) {
        synchronized (FileStore.LOCK) {
            // the screen's copy may be out of date (e.g. already cancelled elsewhere): trust the file
            Reservation r = ReservationFileHandler.findById(stale.getBookingId());
            if (r == null) {
                return new CancelResult(false, "This booking no longer exists.");
            }
            LocalDate today = LocalDate.now();
            if (!CancellationPolicy.canCancel(r, today, byAdmin)) {
                return new CancelResult(false, "This booking can no longer be cancelled.");
            }
            if (!ReservationFileHandler.cancel(r.getBookingId())) {
                return new CancelResult(false, "Could not update the reservation file. Nothing was changed.");
            }
            Payment p = PaymentFileHandler.findByBooking(r.getBookingId());
            if (p == null) {
                return new CancelResult(true, "Reservation " + r.getBookingId() + " cancelled.");
            }
            boolean saved = true;
            String msg;
            if (Payment.PAID.equals(p.getStatus())) {
                double fee = CancellationPolicy.fee(r, p.getAmount(), today, waiveFee);
                double refund = p.getAmount() - fee;
                saved = PaymentFileHandler.update(p.getPaymentId(), Payment.REFUNDED, refund);
                msg = String.format(Locale.US, "Reservation %s cancelled.%nRefund: \u20B1%,.2f to %s (%s).",
                        r.getBookingId(), refund, p.getMethod(), p.getReference());
                if (fee > 0) {
                    msg += String.format(Locale.US, "%nLate-cancellation fee kept: \u20B1%,.2f.", fee);
                }
            } else if (Payment.PENDING.equals(p.getStatus())) {
                saved = PaymentFileHandler.updateStatus(p.getPaymentId(), Payment.VOID);
                msg = "Reservation " + r.getBookingId() + " cancelled.\nNo payment had been collected.";
            } else {
                msg = "Reservation " + r.getBookingId() + " cancelled.";
            }
            if (!saved) { // keep both files consistent
                ReservationFileHandler.setStatus(r.getBookingId(), Reservation.CONFIRMED);
                return new CancelResult(false, "Could not update the payment file, so the cancellation was undone. Please try again.");
            }
            return new CancelResult(true, msg);
        }
    }

    // ------------------------------------------------------------ stay lifecycle (front desk)

    /** Guest arrives. Cash bookings must be paid first (the front desk collects it here). */
    public static CancelResult checkIn(Reservation stale, boolean cashCollected) {
        synchronized (FileStore.LOCK) {
            Reservation r = ReservationFileHandler.findById(stale.getBookingId());
            if (r == null) {
                return new CancelResult(false, "This booking no longer exists.");
            }
            LocalDate today = LocalDate.now();
            if (!Reservation.CONFIRMED.equals(r.getStatus())) {
                return new CancelResult(false, "Only a CONFIRMED booking can be checked in.");
            }
            if (today.isBefore(r.getCheckIn())) {
                return new CancelResult(false, "Too early: check-in is on " + r.getCheckIn() + ".");
            }
            if (!today.isBefore(r.getCheckOut())) {
                return new CancelResult(false, "This stay has already ended.");
            }
            Payment p = PaymentFileHandler.findByBooking(r.getBookingId());
            if (p != null && Payment.PENDING.equals(p.getStatus())) {
                if (!cashCollected) {
                    return new CancelResult(false, "Payment is still pending. Collect it before checking the guest in.");
                }
                if (!PaymentFileHandler.updateStatus(p.getPaymentId(), Payment.PAID)) {
                    return new CancelResult(false, "Could not record the payment.");
                }
            }
            return ReservationFileHandler.setStatus(r.getBookingId(), Reservation.CHECKED_IN)
                    ? new CancelResult(true, "Guest checked in.")
                    : new CancelResult(false, "Could not update the reservation file.");
        }
    }

    public static CancelResult checkOut(Reservation stale) {
        Reservation r = ReservationFileHandler.findById(stale.getBookingId());
        if (r == null) {
            return new CancelResult(false, "This booking no longer exists.");
        }
        if (!Reservation.CHECKED_IN.equals(r.getStatus())) {
            return new CancelResult(false, "Only a CHECKED_IN guest can be checked out.");
        }
        return ReservationFileHandler.setStatus(r.getBookingId(), Reservation.COMPLETED)
                ? new CancelResult(true, "Guest checked out. Stay completed.")
                : new CancelResult(false, "Could not update the reservation file.");
    }

    /**
     * Housekeeping, run at startup and whenever the admin opens Reservations:
     *  CONFIRMED whose stay is over -> NO_SHOW (and an unpaid cash payment becomes VOID);
     *  CHECKED_IN whose stay is over -> COMPLETED (the desk forgot to check them out).
     * Returns how many reservations changed.
     */
    public static int sweep(LocalDate today) {
        synchronized (FileStore.LOCK) {
            ArrayList<Reservation> all = ReservationFileHandler.loadAll();
            int changed = 0;
            for (Reservation r : all) {
                if (r.getCheckOut().isAfter(today) || r.getCheckOut().isEqual(today)) {
                    continue; // stay not over yet (checkout day itself is still "today")
                }
                if (Reservation.CONFIRMED.equals(r.getStatus())) {
                    r.setStatus(Reservation.NO_SHOW);
                    Payment p = PaymentFileHandler.findByBooking(r.getBookingId());
                    if (p != null && Payment.PENDING.equals(p.getStatus())) {
                        PaymentFileHandler.updateStatus(p.getPaymentId(), Payment.VOID);
                    }
                    changed++;
                } else if (Reservation.CHECKED_IN.equals(r.getStatus())) {
                    r.setStatus(Reservation.COMPLETED);
                    changed++;
                }
            }
            if (changed > 0) {
                ReservationFileHandler.saveAll(all);
            }
            return changed;
        }
    }

    /** Most bookings of this room type that overlap on any single night from today on (an admin cannot cut units below it). */
    public static int maxBookedAtOnce(String roomId, LocalDate from) {
        List<Reservation> mine = new ArrayList<>();
        for (Reservation r : ReservationFileHandler.loadAll()) {
            if (r.getRoomId().equals(roomId) && r.isActive() && r.getCheckOut().isAfter(from)) {
                mine.add(r);
            }
        }
        int max = 0;
        for (Reservation r : mine) { // the busiest night always starts on some booking's check-in (or today)
            LocalDate night = r.getCheckIn().isBefore(from) ? from : r.getCheckIn();
            int count = 0;
            for (Reservation o : mine) {
                if (!o.getCheckIn().isAfter(night) && o.getCheckOut().isAfter(night)) {
                    count++;
                }
            }
            max = Math.max(max, count);
        }
        return max;
    }

    public static long nightsBetween(LocalDate a, LocalDate b) {
        return ChronoUnit.DAYS.between(a, b);
    }
}
