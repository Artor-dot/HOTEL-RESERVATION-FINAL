package service;

import model.Payment;

import java.io.File;
import java.time.LocalDate;
import java.util.ArrayList;

/** Reads and writes data/payments.txt (format is documented in model/Payment.java) */
public class PaymentFileHandler {

    public static File paymentsFile() {
        return DataPaths.file("payments.txt");
    }

    // FILE READING
    public static ArrayList<Payment> loadAll() {
        ArrayList<Payment> list = new ArrayList<>();
        synchronized (FileStore.LOCK) {
            for (String line : FileStore.readLines(paymentsFile())) {
                Payment p = Payment.fromLine(line);
                if (p != null) {
                    list.add(p);
                }
            }
        }
        return list;
    }

    // FILE WRITING (atomic)
    public static boolean saveAll(ArrayList<Payment> list) {
        ArrayList<String> lines = new ArrayList<>();
        for (Payment p : list) {
            lines.add(p.toFileLine());
        }
        synchronized (FileStore.LOCK) {
            return FileStore.writeLines(paymentsFile(), lines);
        }
    }

    public static boolean add(Payment p) {
        synchronized (FileStore.LOCK) {
            ArrayList<Payment> list = loadAll();
            list.add(p);
            return saveAll(list);
        }
    }

    public static boolean remove(String paymentId) {
        synchronized (FileStore.LOCK) {
            ArrayList<Payment> list = loadAll();
            if (!list.removeIf(p -> p.getPaymentId().equals(paymentId))) {
                return false;
            }
            return saveAll(list);
        }
    }

    public static ArrayList<Payment> loadForUser(String username) {
        ArrayList<Payment> mine = new ArrayList<>();
        for (Payment p : loadAll()) {
            if (p.getUsername().equalsIgnoreCase(username)) {
                mine.add(p);
            }
        }
        return mine;
    }

    public static Payment findByBooking(String bookingId) {
        for (Payment p : loadAll()) {
            if (p.getBookingId().equals(bookingId)) {
                return p;
            }
        }
        return null;
    }

    public static boolean updateStatus(String paymentId, String newStatus) {
        return update(paymentId, newStatus, null);
    }

    /** Sets the status and (if not null) the refunded amount in one save. */
    public static boolean update(String paymentId, String newStatus, Double refundAmount) {
        synchronized (FileStore.LOCK) {
            ArrayList<Payment> list = loadAll();
            for (Payment p : list) {
                if (p.getPaymentId().equals(paymentId)) {
                    p.setStatus(newStatus);
                    if (refundAmount != null) {
                        p.setRefundAmount(refundAmount);
                    }
                    return saveAll(list);
                }
            }
        }
        return false;
    }

    /** Next id like PAY-2026-0001 */
    public static String nextPaymentId() {
        int max = 0;
        for (Payment p : loadAll()) {
            String id = p.getPaymentId();
            try {
                max = Math.max(max, Integer.parseInt(id.substring(id.lastIndexOf('-') + 1)));
            } catch (NumberFormatException e) {
                // ignore ids we can't read
            }
        }
        return String.format("PAY-%d-%04d", LocalDate.now().getYear(), max + 1);
    }
}
