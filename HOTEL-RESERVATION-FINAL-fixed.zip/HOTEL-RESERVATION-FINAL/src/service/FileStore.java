package service;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

/**
 * The one place that touches the text files.
 *  - LOCK: every read-modify-write in the service layer synchronizes on it, so two threads
 *    can never interleave and lose each other's changes.
 *  - writeLines: writes to a temp file first and then swaps it in, so a crash half-way
 *    through a save can never leave a half-written (corrupt) data file.
 */
final class FileStore {
    static final Object LOCK = new Object();

    private FileStore() { }

    /** Non-empty, trimmed lines; empty list if the file does not exist yet. */
    static ArrayList<String> readLines(File file) {
        ArrayList<String> out = new ArrayList<>();
        if (!file.isFile()) {
            return out;
        }
        try {
            for (String line : Files.readAllLines(file.toPath(), StandardCharsets.UTF_8)) {
                line = line.trim();
                if (!line.isEmpty()) {
                    out.add(line);
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading " + file.getName() + ": " + e.getMessage());
        }
        return out;
    }

    static boolean writeLines(File file, List<String> lines) {
        File folder = file.getAbsoluteFile().getParentFile();
        if (folder != null && !folder.exists() && !folder.mkdirs()) {
            return false;
        }
        File tmp = new File(folder, file.getName() + ".tmp");
        try {
            StringBuilder sb = new StringBuilder();
            for (String l : lines) {
                sb.append(l).append(System.lineSeparator());
            }
            Files.write(tmp.toPath(), sb.toString().getBytes(StandardCharsets.UTF_8));
            try {
                Files.move(tmp.toPath(), file.toPath(),
                        StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING);
            }
            return true;
        } catch (IOException e) {
            System.out.println("Error saving " + file.getName() + ": " + e.getMessage());
            tmp.delete();
            return false;
        }
    }
}
