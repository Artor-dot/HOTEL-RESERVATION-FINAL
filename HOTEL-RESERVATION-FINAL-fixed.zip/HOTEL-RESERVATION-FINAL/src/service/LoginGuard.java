package service;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Slows down password guessing: 5 wrong tries on the same account locks it for 60 seconds. */
public final class LoginGuard {
    public static final int MAX_FAILS = 5;
    public static final long LOCK_MS = 60_000;

    private static final class Entry { int fails; long lockedUntil; }
    private static final Map<String, Entry> ENTRIES = new HashMap<>();

    private LoginGuard() { }

    /** Seconds still locked (0 = free to try). */
    public static synchronized long secondsLocked(String key) {
        Entry e = ENTRIES.get(norm(key));
        if (e == null) {
            return 0;
        }
        long left = e.lockedUntil - System.currentTimeMillis();
        return left > 0 ? (left + 999) / 1000 : 0;
    }

    public static synchronized void fail(String key) {
        Entry e = ENTRIES.computeIfAbsent(norm(key), k -> new Entry());
        if (e.lockedUntil > 0 && e.lockedUntil <= System.currentTimeMillis()) {
            e.fails = 0; // old lock ran out
            e.lockedUntil = 0;
        }
        e.fails++;
        if (e.fails >= MAX_FAILS) {
            e.lockedUntil = System.currentTimeMillis() + LOCK_MS;
        }
    }

    public static synchronized void success(String key) {
        ENTRIES.remove(norm(key));
    }

    public static synchronized void resetAll() {
        ENTRIES.clear();
    }

    private static String norm(String key) {
        return key.trim().toLowerCase(Locale.ROOT);
    }
}
