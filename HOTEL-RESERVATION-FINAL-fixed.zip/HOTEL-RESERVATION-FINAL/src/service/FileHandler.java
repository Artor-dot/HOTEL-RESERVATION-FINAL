package service;

import model.User;

import java.io.File;
import java.util.ArrayList;
import java.util.Locale;

/**
 * Reads and writes data/users.txt
 * Format per line: fullName|email|username|passwordHash|role|status|blockReason|securityQuestion|securityAnswerHash
 */
public class FileHandler {

    public static File usersFile() {
        return DataPaths.file("users.txt");
    }

    // FILE READING: load every user from the text file
    public static ArrayList<User> loadUsers() {
        ArrayList<User> users = new ArrayList<>();
        synchronized (FileStore.LOCK) {
            for (String line : FileStore.readLines(usersFile())) {
                String[] p = line.split("\\|", -1);
                if (p.length == 4) { // oldest format: plain active guest
                    users.add(new User(p[0], p[1], p[2], p[3], User.GUEST, false, ""));
                } else if (p.length == 7) {
                    users.add(new User(p[0], p[1], p[2], p[3], p[4], "BLOCKED".equals(p[5]), p[6]));
                } else if (p.length == 9) {
                    users.add(new User(p[0], p[1], p[2], p[3], p[4], "BLOCKED".equals(p[5]), p[6], p[7], p[8]));
                }
            }
        }
        return users;
    }

    // FILE WRITING: overwrite the file with the current list (atomic - see FileStore)
    public static boolean saveUsers(ArrayList<User> users) {
        ArrayList<String> lines = new ArrayList<>();
        for (User u : users) {
            lines.add(u.toFileLine());
        }
        synchronized (FileStore.LOCK) {
            return FileStore.writeLines(usersFile(), lines);
        }
    }

    public static boolean usernameExists(String username) {
        return findByUsername(username) != null;
    }

    public static User findByUsername(String username) {
        for (User u : loadUsers()) {
            if (u.getUsername().equalsIgnoreCase(username.trim())) {
                return u;
            }
        }
        return null;
    }

    /** True if ANY account (blocked or not) already uses this email. */
    public static boolean emailExists(String email) {
        return emailExists(email, null);
    }

    /** Same, ignoring one account (used when a user edits their own profile). */
    public static boolean emailExists(String email, String exceptUsername) {
        for (User u : loadUsers()) {
            boolean other = exceptUsername == null || !u.getUsername().equalsIgnoreCase(exceptUsername);
            if (other && u.getEmail().equalsIgnoreCase(email.trim())) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns the User if username + password match, otherwise null (the caller checks user.isBlocked()).
     * Repeated failures lock the account for a minute (LoginGuard). Old plain-text passwords are
     * upgraded to hashes the first time their owner logs in.
     */
    public static User login(String username, String password) {
        if (LoginGuard.secondsLocked(username) > 0) {
            return null;
        }
        synchronized (FileStore.LOCK) {
            ArrayList<User> users = loadUsers();
            for (User u : users) {
                if (u.getUsername().equalsIgnoreCase(username.trim())) {
                    if (PasswordHasher.verify(password, u.getPassword())) {
                        LoginGuard.success(username);
                        if (!PasswordHasher.isHashed(u.getPassword())) {
                            u.setPassword(PasswordHasher.hash(password));
                            saveUsers(users);
                        }
                        return u;
                    }
                    break;
                }
            }
        }
        LoginGuard.fail(username);
        return null;
    }

    public static boolean addUser(User newUser) {
        synchronized (FileStore.LOCK) {
            ArrayList<User> users = loadUsers();
            for (User u : users) { // last line of defence against duplicates
                if (u.getUsername().equalsIgnoreCase(newUser.getUsername())
                        || u.getEmail().equalsIgnoreCase(newUser.getEmail())) {
                    return false;
                }
            }
            users.add(newUser);
            return saveUsers(users);
        }
    }

    // ------------------------------------------------------------ security question + reset

    public static String normalizeAnswer(String answer) {
        return answer.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
    }

    /** The question to show on the reset screen, or null (no such guest / no question / admin). */
    public static String securityQuestionFor(String username, String email) {
        User u = findByUsername(username);
        if (u == null || u.isAdmin() || !u.hasSecurityQuestion() || !u.getEmail().equalsIgnoreCase(email.trim())) {
            return null;
        }
        return u.getSecQuestion();
    }

    /**
     * Self-service password reset. Needs the username, the email AND the answer to the account's
     * security question. Admin accounts can never be reset here. Returns null on success, else a message.
     */
    public static String resetPassword(String username, String email, String answer, String newPassword) {
        String key = "reset:" + username;
        long wait = LoginGuard.secondsLocked(key);
        if (wait > 0) {
            return "Too many wrong attempts. Please wait " + wait + " seconds and try again.";
        }
        String pwError = Validators.password(newPassword);
        if (pwError != null) {
            return pwError;
        }
        synchronized (FileStore.LOCK) {
            ArrayList<User> users = loadUsers();
            for (User u : users) {
                if (!u.getUsername().equalsIgnoreCase(username.trim())) {
                    continue;
                }
                if (u.isAdmin()) {
                    return "Admin passwords cannot be reset here. Please contact the system owner.";
                }
                if (!u.hasSecurityQuestion()) {
                    return "This account has no security question. Please ask the front desk to help you.";
                }
                if (u.getEmail().equalsIgnoreCase(email.trim())
                        && PasswordHasher.verify(normalizeAnswer(answer), u.getSecAnswer())) {
                    LoginGuard.success(key);
                    u.setPassword(PasswordHasher.hash(newPassword));
                    return saveUsers(users) ? null : "Could not save the new password. Please try again.";
                }
                break;
            }
        }
        LoginGuard.fail(key);
        return "Those details do not match our records.";
    }

    // ------------------------------------------------------------ profile (logged-in guest)

    public static String changePassword(String username, String current, String newPassword) {
        String pwError = Validators.password(newPassword);
        if (pwError != null) {
            return pwError;
        }
        synchronized (FileStore.LOCK) {
            ArrayList<User> users = loadUsers();
            for (User u : users) {
                if (u.getUsername().equalsIgnoreCase(username)) {
                    if (!PasswordHasher.verify(current, u.getPassword())) {
                        return "Your current password is not correct.";
                    }
                    u.setPassword(PasswordHasher.hash(newPassword));
                    return saveUsers(users) ? null : "Could not save the new password.";
                }
            }
        }
        return "Account not found.";
    }

    public static String updateProfile(String username, String fullName, String email) {
        String err = Validators.fullName(fullName);
        if (err == null) {
            err = Validators.email(email);
        }
        if (err != null) {
            return err;
        }
        synchronized (FileStore.LOCK) {
            if (emailExists(email, username)) {
                return "That email is already used by another account.";
            }
            ArrayList<User> users = loadUsers();
            for (User u : users) {
                if (u.getUsername().equalsIgnoreCase(username)) {
                    u.setFullName(fullName.trim());
                    u.setEmail(email.trim());
                    return saveUsers(users) ? null : "Could not save your profile.";
                }
            }
        }
        return "Account not found.";
    }

    public static String setSecurityQuestion(String username, String currentPassword, String question, String answer) {
        if (question == null || question.isBlank() || answer == null || answer.trim().length() < 2) {
            return "Please choose a question and give an answer (at least 2 characters).";
        }
        synchronized (FileStore.LOCK) {
            ArrayList<User> users = loadUsers();
            for (User u : users) {
                if (u.getUsername().equalsIgnoreCase(username)) {
                    if (!PasswordHasher.verify(currentPassword, u.getPassword())) {
                        return "Your current password is not correct.";
                    }
                    u.setSecurity(question, PasswordHasher.hash(normalizeAnswer(answer)));
                    return saveUsers(users) ? null : "Could not save.";
                }
            }
        }
        return "Account not found.";
    }

    /** Admin feature: set a temporary password for a guest who cannot self-reset. */
    public static boolean adminSetPassword(String username, String newPassword) {
        synchronized (FileStore.LOCK) {
            ArrayList<User> users = loadUsers();
            for (User u : users) {
                if (u.getUsername().equalsIgnoreCase(username) && !u.isAdmin()) {
                    u.setPassword(PasswordHasher.hash(newPassword));
                    return saveUsers(users);
                }
            }
        }
        return false;
    }

    /** Runs at startup: converts any plain-text password / security answer left in the file into a hash. */
    public static int migratePasswords() {
        synchronized (FileStore.LOCK) {
            ArrayList<User> users = loadUsers();
            int changed = 0;
            for (User u : users) {
                if (!PasswordHasher.isHashed(u.getPassword())) {
                    u.setPassword(PasswordHasher.hash(u.getPassword()));
                    changed++;
                }
                if (u.hasSecurityQuestion() && !PasswordHasher.isHashed(u.getSecAnswer())) {
                    u.setSecurity(u.getSecQuestion(), PasswordHasher.hash(normalizeAnswer(u.getSecAnswer())));
                    changed++;
                }
            }
            if (changed > 0) {
                saveUsers(users);
            }
            return changed;
        }
    }

    // ------------------------------------------------------------ blocklist

    /** Blocks or unblocks an account (admin feature). Admin accounts can never be blocked. */
    public static boolean setBlocked(String username, boolean blocked, String reason) {
        synchronized (FileStore.LOCK) {
            ArrayList<User> users = loadUsers();
            for (User u : users) {
                if (u.getUsername().equalsIgnoreCase(username)) {
                    if (u.isAdmin() && blocked) {
                        return false;
                    }
                    u.setBlocked(blocked, reason);
                    return saveUsers(users);
                }
            }
        }
        return false;
    }

    public static boolean isBlocked(String username) {
        User u = findByUsername(username);
        return u != null && u.isBlocked();
    }

    /** True if a blocked account already uses this email (stops troll re-registration). */
    public static boolean isEmailBlocked(String email) {
        for (User u : loadUsers()) {
            if (u.isBlocked() && u.getEmail().equalsIgnoreCase(email.trim())) {
                return true;
            }
        }
        return false;
    }
}
